import type { DeteccaoCaixa } from "@/lib/universal-inference";

export function DetectionOverlay({
  deteccoes,
  larguraOriginal,
  alturaOriginal,
}: {
  deteccoes: DeteccaoCaixa[];
  larguraOriginal: number;
  alturaOriginal: number;
}) {
  if (!larguraOriginal || !alturaOriginal) return null;
  return (
    <svg
      viewBox={`0 0 ${larguraOriginal} ${alturaOriginal}`}
      preserveAspectRatio="none"
      className="pointer-events-none absolute inset-0 size-full"
      aria-hidden="true"
    >
      {deteccoes.map((d, i) => {
        const [x, y, w, h] = d.box;
        const rotulo = `${d.className} ${(d.score * 100).toFixed(0)}%`;
        return (
          <g key={i} className="detection-mark" style={{ animationDelay: `${i * 120}ms` }}>
            <rect
              x={x}
              y={y}
              width={w}
              height={h}
              fill="none"
              stroke="currentColor"
              strokeWidth={Math.max(2, larguraOriginal / 250)}
              className="detection-box text-detection"
              pathLength={1}
            />
            <text
              x={x + 4}
              y={Math.max(12, y - 6)}
              fontSize={Math.max(12, larguraOriginal / 60)}
              className="detection-label fill-detection font-mono font-bold"
              style={{ paintOrder: "stroke", stroke: "var(--overlay-label-stroke)", strokeWidth: 3 }}
            >
              {rotulo}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
