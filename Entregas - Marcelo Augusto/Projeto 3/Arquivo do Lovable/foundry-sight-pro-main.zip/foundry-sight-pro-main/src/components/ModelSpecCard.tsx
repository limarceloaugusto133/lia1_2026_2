import { AlertTriangle } from "lucide-react";
import type { ModelSpec } from "@/lib/model-spec";
import type { DecisionResult, RuleTone } from "@/lib/decision-rules";
import { Slider } from "@/components/ui/slider";
import { CircleHelp } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

const TOM_CLASSES: Record<RuleTone, string> = {
  alerta: "text-destructive",
  atencao: "text-warning",
  ok: "text-success",
  neutro: "text-foreground",
};

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="border-t border-border px-5 py-4 first:border-t-0">
      <p className="mb-1.5 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
      </p>
      <div className="font-mono text-sm text-card-foreground">{children}</div>
    </div>
  );
}

function formatarEntrada(spec: ModelSpec): string {
  const { entrada } = spec;
  const tipo = entrada.canais === 1 ? "GRAY" : entrada.canais === 3 ? "RGB" : `${entrada.canais}ch`;
  return `images · ${entrada.formato} · ${entrada.largura}×${entrada.altura} · ${tipo} · ${entrada.preprocessamento}`;
}

export interface ModelSpecCardProps {
  spec: ModelSpec;
  confiancaMinima: number;
  onConfiancaMinimaChange: (v: number) => void;
  regrasTexto: string;
  onRegrasTextoChange: (v: string) => void;
  regrasErros: string[];
  decisaoAtual?: DecisionResult | null;
  editandoRegras: boolean;
  onToggleEditarRegras: () => void;
}

export function ModelSpecCard({
  spec,
  confiancaMinima,
  onConfiancaMinimaChange,
  regrasTexto,
  onRegrasTextoChange,
  regrasErros,
  decisaoAtual,
  editandoRegras,
  onToggleEditarRegras,
}: ModelSpecCardProps) {
  const temMetricas =
    !!spec.metricas &&
    (spec.metricas.map50 !== undefined ||
      spec.metricas.map50_95 !== undefined ||
      spec.metricas.epoca !== undefined);

  return (
    <div className="animate-card-in overflow-hidden rounded-lg border border-border bg-card text-card-foreground shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
      <div className="px-5 pb-4 pt-5">
        <h2 className="font-display text-lg font-bold leading-tight">
          {spec.nomeProblema}
          {spec.nomeModelo && spec.nomeModelo !== spec.nomeProblema ? (
            <span className="text-muted-foreground"> ({spec.nomeModelo})</span>
          ) : null}
        </h2>
        {(spec.producer ?? spec.producerVersion) && (
          <p className="mt-0.5 font-mono text-[11px] text-muted-foreground">
            {spec.producer ?? "produtor desconhecido"} {spec.producerVersion ?? ""}
          </p>
        )}
      </div>

      {temMetricas && (
        <div className="grid grid-cols-3 divide-x divide-border border-t border-border">
          <MetricBlock label="MAP50" value={spec.metricas?.map50} tooltip="Precisão média do modelo quando uma sobreposição de 50% é considerada correta." />
          <MetricBlock label="MAP50-95" value={spec.metricas?.map50_95} />
          <MetricBlock label="ÉPOCA" value={spec.metricas?.epoca} isInt />
        </div>
      )}

      <Row label={`Classes ${spec.classes.length}`}>
        <div className="flex flex-wrap gap-1.5">
          {spec.classes.map((c) => (
            <span key={c} className="rounded border border-border bg-muted/40 px-2 py-0.5 text-xs">
              {c}
            </span>
          ))}
        </div>
        {spec.classesOrigem === "inferido_generico" && (
          <p className="mt-2 flex items-center gap-1.5 text-[11px] text-amber-400">
            <AlertTriangle className="size-3" /> nomes genéricos — envie um config.json com
            "classes" para nomes reais
          </p>
        )}
      </Row>

      <Row label="Entrada">
        <div className="flex flex-wrap items-center gap-2">
          <span>{formatarEntrada(spec)}</span>
          <Tooltip>
            <TooltipTrigger asChild>
              <button type="button" className="inline-flex items-center gap-1 text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                {spec.entrada.preprocessamento}<CircleHelp className="size-3" />
              </button>
            </TooltipTrigger>
            <TooltipContent className="max-w-60 bg-popover text-popover-foreground">
              {spec.entrada.preprocessamento === "letterbox"
                ? "Redimensiona sem distorcer a imagem e completa as bordas até o formato do modelo."
                : "Redimensiona a imagem diretamente para o formato esperado pelo modelo."}
            </TooltipContent>
          </Tooltip>
        </div>
      </Row>
      <Row label="Saída">
        {spec.saida.nomes.join(", ")}
        {spec.saida.descricao ? (
          <span className="text-muted-foreground"> · {spec.saida.descricao}</span>
        ) : null}
      </Row>

      <Row label="Decisão">
        {decisaoAtual ? (
          <p>
            <span className={`font-bold ${TOM_CLASSES[decisaoAtual.tom]}`}>
              {decisaoAtual.rotulo}
            </span>
            <span className="text-muted-foreground"> · {decisaoAtual.expressaoTexto}</span>
          </p>
        ) : (
          <p className="whitespace-pre-line text-muted-foreground">{regrasTexto}</p>
        )}
        <button
          type="button"
          onClick={onToggleEditarRegras}
          className="mt-2 text-[11px] uppercase tracking-wide text-primary underline underline-offset-2"
        >
          {editandoRegras ? "concluir edição" : "editar regras"}
        </button>
        {editandoRegras && (
          <div className="mt-2 space-y-1.5">
            <textarea
              value={regrasTexto}
              onChange={(e) => onRegrasTextoChange(e.target.value)}
              rows={4}
              spellCheck={false}
              className="w-full rounded border border-input bg-background p-2 font-mono text-xs text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-ring/30"
              placeholder={"Rótulo | expressão\nex.: Buraco na via | buraco >= 0.5"}
            />
            {regrasErros.length > 0 && (
              <ul className="space-y-0.5 text-[11px] text-destructive">
                {regrasErros.map((e, i) => (
                  <li key={i}>⚠ {e}</li>
                ))}
              </ul>
            )}
          </div>
        )}
      </Row>

      {spec.origemTexto && <Row label="Origem">{spec.origemTexto}</Row>}
      {spec.exportadoEm && <Row label="Exportado">{spec.exportadoEm}</Row>}

      <div className="border-t border-border px-5 pt-4">
        <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Operação</p>
      </div>

      <div className="px-5 py-4">
        <div className="mb-2 flex items-center justify-between">
          <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            <Tooltip><TooltipTrigger asChild><span className="inline-flex cursor-help items-center gap-1">Confiança mínima <CircleHelp className="size-3" /></span></TooltipTrigger><TooltipContent className="max-w-60 bg-popover text-popover-foreground">Pontuação mínima para uma predição aparecer no resultado.</TooltipContent></Tooltip>
          </p>
          <p className="font-mono text-sm font-bold text-foreground">
            {Math.round(confiancaMinima * 100)}%
          </p>
        </div>
        <Slider
          value={[confiancaMinima * 100]}
          min={0}
          max={100}
          step={1}
          onValueChange={([v]) => onConfiancaMinimaChange((v ?? 35) / 100)}
        />
      </div>

      {spec.avisos.length > 0 && (
        <div className="space-y-1 border-t border-border bg-warning/5 px-5 py-3">
          {spec.avisos.map((a, i) => (
            <p
              key={i}
              className="flex items-start gap-1.5 text-[11px] leading-relaxed text-amber-400"
            >
              <AlertTriangle className="mt-0.5 size-3 shrink-0" /> {a}
            </p>
          ))}
        </div>
      )}
    </div>
  );
}

function MetricBlock({
  label,
  value,
  isInt,
  tooltip,
}: {
  label: string;
  value: number | string | undefined;
  isInt?: boolean;
  tooltip?: string;
}) {
  return (
    <div className="px-4 py-4 text-center">
      <p className="mb-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{tooltip ? <Tooltip><TooltipTrigger asChild><span className="inline-flex cursor-help items-center gap-1">{label}<CircleHelp className="size-3" /></span></TooltipTrigger><TooltipContent className="max-w-60 bg-popover text-popover-foreground">{tooltip}</TooltipContent></Tooltip> : label}</p>
      <p className="font-display text-2xl font-bold">
        {value === undefined
          ? "—"
          : isInt
            ? value
            : typeof value === "number"
              ? value.toFixed(3)
              : value}
      </p>
    </div>
  );
}
