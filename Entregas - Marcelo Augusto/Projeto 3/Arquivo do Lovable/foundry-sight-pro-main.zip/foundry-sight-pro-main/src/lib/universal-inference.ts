import type { EntradaSpec, ModelSpec } from "./model-spec";

// ---------------------------------------------------------------------------
// Sessão ONNX Runtime — criada a partir dos BYTES do arquivo (não de uma URL
// fixa), para funcionar com qualquer .onnx que o usuário envie. O import de
// "onnxruntime-web" é dinâmico e só acontece no navegador (evita quebrar o
// SSR do TanStack Start, igual ao app original).
// ---------------------------------------------------------------------------

let ortModulePromise: Promise<typeof import("onnxruntime-web")> | null = null;
function carregarOrt() {
  if (!ortModulePromise) {
    ortModulePromise = import("onnxruntime-web").then((ort) => {
      ort.env.wasm.numThreads = 1; // evita exigir cabeçalhos COOP/COEP
      ort.env.wasm.simd = true;
      return ort;
    });
  }
  return ortModulePromise;
}

export class ModeloInvalidoError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ModeloInvalidoError";
  }
}

export async function criarSessaoDeBytes(
  bytes: Uint8Array,
): Promise<import("onnxruntime-web").InferenceSession> {
  const ort = await carregarOrt();
  try {
    return await ort.InferenceSession.create(bytes, { executionProviders: ["wasm"] });
  } catch (e) {
    throw new ModeloInvalidoError(
      `O ONNX Runtime não conseguiu carregar este modelo. Ele pode usar operadores não suportados no navegador, estar corrompido, ou não ser um arquivo .onnx válido. Detalhe técnico: ${e instanceof Error ? e.message : String(e)}`,
    );
  }
}

// ---------------------------------------------------------------------------
// Pré-processamento genérico da imagem
// ---------------------------------------------------------------------------

export interface TransformacaoLetterbox {
  escala: number;
  padX: number;
  padY: number;
  larguraOriginal: number;
  alturaOriginal: number;
}

export interface ImagemPreprocessada {
  tensorData: Float32Array;
  letterbox?: TransformacaoLetterbox | undefined;
}

/** Desenha a imagem redimensionada (com ou sem letterbox) num canvas e devolve os pixels RGBA. */
function desenharNoCanvas(
  bitmap: ImageBitmap,
  largura: number,
  altura: number,
  preprocessamento: EntradaSpec["preprocessamento"],
): { imageData: ImageData; letterbox?: TransformacaoLetterbox | undefined } {
  const canvas = document.createElement("canvas");
  canvas.width = largura;
  canvas.height = altura;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas 2D indisponível neste navegador.");
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";

  if (preprocessamento === "letterbox") {
    const escala = Math.min(largura / bitmap.width, altura / bitmap.height);
    const novaLargura = Math.round(bitmap.width * escala);
    const novaAltura = Math.round(bitmap.height * escala);
    const padX = Math.floor((largura - novaLargura) / 2);
    const padY = Math.floor((altura - novaAltura) / 2);
    ctx.fillStyle = "rgb(114,114,114)"; // cinza neutro, padrão do letterbox do Ultralytics YOLO
    ctx.fillRect(0, 0, largura, altura);
    ctx.drawImage(bitmap, 0, 0, bitmap.width, bitmap.height, padX, padY, novaLargura, novaAltura);
    return {
      imageData: ctx.getImageData(0, 0, largura, altura),
      letterbox: {
        escala,
        padX,
        padY,
        larguraOriginal: bitmap.width,
        alturaOriginal: bitmap.height,
      },
    };
  }

  ctx.drawImage(bitmap, 0, 0, largura, altura);
  return { imageData: ctx.getImageData(0, 0, largura, altura) };
}

/**
 * Converte uma imagem (File) no tensor de entrada esperado pelo modelo,
 * seguindo o formato/tamanho/canais/pré-processamento descritos em `entrada`.
 * Não assume RGB vs. cinza nem NCHW vs. NHWC — tudo vem de `entrada`.
 */
export async function preprocessarImagem(
  arquivo: File,
  entrada: EntradaSpec,
): Promise<ImagemPreprocessada> {
  let bitmap: ImageBitmap;
  try {
    bitmap = await createImageBitmap(arquivo);
  } catch (e) {
    throw new Error(
      `Não foi possível decodificar "${arquivo.name}" como imagem (arquivo corrompido ou formato não suportado): ${e instanceof Error ? e.message : String(e)}`,
    );
  }

  const { largura, altura, canais } = entrada;
  const { imageData, letterbox } = desenharNoCanvas(
    bitmap,
    largura,
    altura,
    entrada.preprocessamento,
  );
  bitmap.close();

  const numPixels = largura * altura;
  const { data } = imageData;
  const [mediaArr, desvioArr] = entrada.normalizacao
    ? [entrada.normalizacao.media, entrada.normalizacao.desvio]
    : [new Array(canais).fill(0), new Array(canais).fill(1)];

  const tensorData = new Float32Array(canais * numPixels);
  const isNCHW = entrada.formato !== "NHWC";

  for (let p = 0; p < numPixels; p++) {
    const r = data[p * 4] ?? 0;
    const g = data[p * 4 + 1] ?? 0;
    const b = data[p * 4 + 2] ?? 0;
    for (let c = 0; c < canais; c++) {
      let valorBruto: number;
      if (canais === 1) {
        valorBruto = 0.299 * r + 0.587 * g + 0.114 * b; // luminância ITU-R BT.601
      } else {
        valorBruto = c === 0 ? r : c === 1 ? g : b;
      }
      const valor01 = valorBruto / 255;
      const media = mediaArr[c] ?? (entrada.normalizacao ? 0 : 0);
      const desvio = desvioArr[c] ?? 1;
      const normalizado = entrada.normalizacao ? (valor01 - media) / (desvio || 1) : valor01;
      if (isNCHW) {
        tensorData[c * numPixels + p] = normalizado;
      } else {
        tensorData[p * canais + c] = normalizado;
      }
    }
  }

  return { tensorData, letterbox };
}

export function shapeDoTensorEntrada(entrada: EntradaSpec): number[] {
  return entrada.formato === "NHWC"
    ? [1, entrada.altura, entrada.largura, entrada.canais]
    : [1, entrada.canais, entrada.altura, entrada.largura];
}

// ---------------------------------------------------------------------------
// Pós-processamento genérico das saídas
// ---------------------------------------------------------------------------

export interface DeteccaoCaixa {
  classeId: number;
  className: string;
  score: number;
  /** [x, y, largura, altura] em pixels da imagem ORIGINAL (já com letterbox revertido) */
  box: [number, number, number, number];
}

export type ResultadoInferencia =
  | {
      tipo: "classificacao";
      scores: Record<string, number>;
      classePrevista: string;
      scorePrevisto: number;
    }
  | {
      tipo: "deteccao";
      deteccoes: DeteccaoCaixa[];
      scores: Record<string, number>; /* melhor score por classe, p/ regras */
    }
  | {
      tipo: "bruto";
      avisos: string[];
      resumo: { nome: string; shape: readonly number[]; min: number; max: number; media: number }[];
    };

function sigmoid(x: number) {
  return 1 / (1 + Math.exp(-x));
}
function softmax(xs: number[]): number[] {
  const m = Math.max(...xs);
  const exps = xs.map((x) => Math.exp(x - m));
  const soma = exps.reduce((a, b) => a + b, 0);
  return exps.map((e) => e / soma);
}
function pareceProbabilidade(xs: Iterable<number>): boolean {
  for (const x of xs) if (x < -0.001 || x > 1.001) return false;
  return true;
}

function iou(a: [number, number, number, number], b: [number, number, number, number]): number {
  const [ax, ay, aw, ah] = a;
  const [bx, by, bw, bh] = b;
  const ax2 = ax + aw;
  const ay2 = ay + ah;
  const bx2 = bx + bw;
  const by2 = by + bh;
  const interX1 = Math.max(ax, bx);
  const interY1 = Math.max(ay, by);
  const interX2 = Math.min(ax2, bx2);
  const interY2 = Math.min(ay2, by2);
  const interW = Math.max(0, interX2 - interX1);
  const interH = Math.max(0, interY2 - interY1);
  const inter = interW * interH;
  const uniao = aw * ah + bw * bh - inter;
  return uniao <= 0 ? 0 : inter / uniao;
}

function nms(caixas: DeteccaoCaixa[], iouThreshold: number, maxSaida: number): DeteccaoCaixa[] {
  const ordenadas = [...caixas].sort((a, b) => b.score - a.score);
  const mantidas: DeteccaoCaixa[] = [];
  for (const cand of ordenadas) {
    if (mantidas.length >= maxSaida) break;
    const sobrepoe = mantidas.some(
      (m) => m.classeId === cand.classeId && iou(m.box, cand.box) > iouThreshold,
    );
    if (!sobrepoe) mantidas.push(cand);
  }
  return mantidas;
}

/** Reverte o letterbox: de coordenadas na imagem "quadrada" pré-processada para pixels da imagem original. */
function desfazerLetterbox(
  box: [number, number, number, number],
  lb: TransformacaoLetterbox,
): [number, number, number, number] {
  const [cx, cy, w, h] = box; // centro + tamanho, no espaço da imagem pré-processada
  const x1 = (cx - w / 2 - lb.padX) / lb.escala;
  const y1 = (cy - h / 2 - lb.padY) / lb.escala;
  const largura = w / lb.escala;
  const altura = h / lb.escala;
  const clampX = Math.max(0, Math.min(x1, lb.larguraOriginal));
  const clampY = Math.max(0, Math.min(y1, lb.alturaOriginal));
  return [
    clampX,
    clampY,
    Math.max(0, Math.min(largura, lb.larguraOriginal - clampX)),
    Math.max(0, Math.min(altura, lb.alturaOriginal - clampY)),
  ];
}

interface DecodeOpcoes {
  classes: string[];
  confThreshold: number;
  iouThreshold?: number | undefined;
  letterbox?: TransformacaoLetterbox | undefined;
  maxDeteccoes?: number | undefined;
}

/**
 * Tenta decodificar as saídas cruas do ONNX Runtime em algo utilizável, sem
 * saber de antemão a "família" do modelo:
 *  - saída escalar (1 valor/imagem)              -> classificador binário (sigmoid)
 *  - saída [1, C] com C = nº de classes            -> classificador multi-classe (softmax)
 *  - saída 3D com um eixo == 4+C ou 5+C            -> detector estilo YOLO (decodifica caixas + NMS)
 *  - qualquer outra coisa                          -> "bruto": mostra estatísticas em vez de travar
 */
export function decodificarSaida(
  outputs: Record<string, { data: ArrayLike<number>; dims: readonly number[] }>,
  opcoes: DecodeOpcoes,
): ResultadoInferencia {
  const nomes = Object.keys(outputs);
  if (nomes.length === 0)
    return { tipo: "bruto", avisos: ["O modelo não retornou nenhuma saída."], resumo: [] };

  const primeiraSaida = outputs[nomes[0] as string];
  const dims = primeiraSaida?.dims ?? [];
  const data = primeiraSaida?.data as ArrayLike<number>;
  const { classes, confThreshold, letterbox, iouThreshold = 0.45, maxDeteccoes = 300 } = opcoes;

  // ---- caso A: escalar por imagem -> classificador binário ----
  const totalElementos = dims.reduce((a, b) => a * b, 1);
  if (
    nomes.length === 1 &&
    (dims.length === 0 || (dims.length === 1 && dims[0] === 1) || totalElementos === 1)
  ) {
    const logit = Number(data[0]);
    const prob = pareceProbabilidade([logit]) ? logit : sigmoid(logit);
    const negativo = classes[0] ?? "classe_0";
    const positivo = classes[classes.length - 1] ?? "classe_1";
    const classePrevista = prob >= confThreshold ? positivo : negativo;
    return {
      tipo: "classificacao",
      scores: { [negativo]: 1 - prob, [positivo]: prob },
      classePrevista,
      scorePrevisto: classePrevista === positivo ? prob : 1 - prob,
    };
  }

  // ---- caso B: [1, C] -> classificador multi-classe ----
  if (dims.length === 2 && dims[0] === 1) {
    const numClasses = dims[1] as number;
    const valores = Array.from(data);
    const probs = pareceProbabilidade(valores) ? valores : softmax(valores);
    const scores: Record<string, number> = {};
    let melhorIdx = 0;
    for (let i = 0; i < numClasses; i++) {
      const nome = classes[i] ?? `classe_${i}`;
      scores[nome] = probs[i] ?? 0;
      if ((probs[i] ?? 0) > (probs[melhorIdx] ?? 0)) melhorIdx = i;
    }
    return {
      tipo: "classificacao",
      scores,
      classePrevista: classes[melhorIdx] ?? `classe_${melhorIdx}`,
      scorePrevisto: probs[melhorIdx] ?? 0,
    };
  }

  // ---- caso C: saída 3D -> tenta decodificar como detecção estilo YOLO ----
  if (dims.length === 3 && dims[0] === 1) {
    const decodificado = tentarDecodificarDeteccao(
      data,
      dims as [number, number, number],
      classes,
      confThreshold,
      iouThreshold,
      maxDeteccoes,
      letterbox,
    );
    if (decodificado) return decodificado;
  }

  // ---- fallback: bruto ----
  const resumo = nomes.map((nome) => {
    const t = outputs[nome];
    if (!t) return { nome, shape: [], min: NaN, max: NaN, media: NaN };
    const vals = Array.from(t.data as ArrayLike<number>);
    const min = vals.length ? Math.min(...vals) : NaN;
    const max = vals.length ? Math.max(...vals) : NaN;
    const media = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : NaN;
    return { nome, shape: t.dims, min, max, media };
  });
  return {
    tipo: "bruto",
    avisos: [
      `Não foi possível decodificar automaticamente a(s) saída(s) deste modelo (formato não reconhecido: ${nomes
        .map((n) => `${n} [${outputs[n]?.dims.join("×")}]`)
        .join(
          ", ",
        )}). Exibindo estatísticas brutas — ajuste a decodificação em universal-inference.ts se precisar suportar esta arquitetura.`,
    ],
    resumo,
  };
}

function tentarDecodificarDeteccao(
  data: ArrayLike<number>,
  dims: [number, number, number],
  classes: string[],
  confThreshold: number,
  iouThreshold: number,
  maxDeteccoes: number,
  letterbox?: TransformacaoLetterbox,
): (ResultadoInferencia & { tipo: "deteccao" }) | null {
  const [, d1, d2] = dims;
  const nc = classes.length;

  // Layout "transposto" (Ultralytics YOLOv8/v11): [1, 4+nc, numCaixas] — sem objectness.
  // Layout "clássico" (YOLOv5/v7): [1, numCaixas, 4+nc] ou [1, numCaixas, 5+nc] (com objectness).
  let numCaixas: number;
  let canaisPorCaixa: number;
  let transposto: boolean;
  let temObjectness = false;

  if (d1 === 4 + nc || d1 === 5 + nc) {
    transposto = true;
    canaisPorCaixa = d1;
    numCaixas = d2;
    temObjectness = d1 === 5 + nc;
  } else if (d2 === 4 + nc || d2 === 5 + nc) {
    transposto = false;
    canaisPorCaixa = d2;
    numCaixas = d1;
    temObjectness = d2 === 5 + nc;
  } else {
    return null; // forma não bate com nenhum layout YOLO conhecido para o nº de classes declarado
  }

  const valor = (caixaIdx: number, canalIdx: number): number => {
    return transposto
      ? Number(data[canalIdx * numCaixas + caixaIdx])
      : Number(data[caixaIdx * canaisPorCaixa + canalIdx]);
  };

  const candidatas: DeteccaoCaixa[] = [];
  const melhorPorClasse: Record<string, number> = {};

  for (let i = 0; i < numCaixas; i++) {
    const cx = valor(i, 0);
    const cy = valor(i, 1);
    const w = valor(i, 2);
    const h = valor(i, 3);
    const objectness = temObjectness ? valor(i, 4) : 1;
    const offsetClasses = temObjectness ? 5 : 4;

    let melhorClasse = 0;
    let melhorScoreClasse = -Infinity;
    for (let c = 0; c < nc; c++) {
      const s = valor(i, offsetClasses + c);
      if (s > melhorScoreClasse) {
        melhorScoreClasse = s;
        melhorClasse = c;
      }
    }
    const scoreClasseNormalizado = pareceProbabilidade([melhorScoreClasse])
      ? melhorScoreClasse
      : sigmoid(melhorScoreClasse);
    const objectnessNormalizado = pareceProbabilidade([objectness])
      ? objectness
      : sigmoid(objectness);
    const score = scoreClasseNormalizado * objectnessNormalizado;

    const nomeClasse = classes[melhorClasse] ?? `classe_${melhorClasse}`;
    if (score > (melhorPorClasse[nomeClasse] ?? 0)) melhorPorClasse[nomeClasse] = score;
    if (score < confThreshold) continue;

    const boxNoEspacoModelo: [number, number, number, number] = [cx, cy, w, h];
    const box = letterbox
      ? desfazerLetterbox(boxNoEspacoModelo, letterbox)
      : [cx - w / 2, cy - h / 2, w, h];
    candidatas.push({
      classeId: melhorClasse,
      className: nomeClasse,
      score,
      box: box as [number, number, number, number],
    });
  }

  const deteccoes = nms(candidatas, iouThreshold, maxDeteccoes);
  for (const nome of classes) melhorPorClasse[nome] = melhorPorClasse[nome] ?? 0;
  return { tipo: "deteccao", deteccoes, scores: melhorPorClasse };
}
