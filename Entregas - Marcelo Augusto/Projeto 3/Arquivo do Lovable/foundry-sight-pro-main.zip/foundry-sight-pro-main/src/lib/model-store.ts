// Persistência local (por navegador) das preferências de cada modelo:
// confiança mínima ajustada e regras de decisão editadas. Chaveado por uma
// "assinatura" simples do modelo (nome do arquivo + tamanho em bytes) — não é
// um hash criptográfico, mas é suficiente para distinguir modelos diferentes
// sem custo de processamento em arquivos que podem ter dezenas de MB.
//
// Edge case: localStorage pode não existir (SSR, modo privado esgotado,
// navegador com storage desabilitado) — todas as funções abaixo toleram isso
// silenciosamente, nunca lançando para não quebrar o fluxo de inferência.

export interface PreferenciasModelo {
  confiancaMinima: number;
  regrasDecisaoTexto: string;
}

const PREFIXO = "onnx-universal:modelo:";

function chave(assinatura: string): string {
  return `${PREFIXO}${assinatura}`;
}

function storageDisponivel(): boolean {
  try {
    return typeof window !== "undefined" && !!window.localStorage;
  } catch {
    return false;
  }
}

export function carregarPreferencias(assinatura: string): Partial<PreferenciasModelo> | null {
  if (!storageDisponivel()) return null;
  try {
    const raw = window.localStorage.getItem(chave(assinatura));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (typeof parsed !== "object" || parsed === null) return null;
    return parsed as Partial<PreferenciasModelo>;
  } catch {
    return null; // JSON corrompido ou storage indisponível — trata como "sem preferências salvas"
  }
}

export function salvarPreferencias(assinatura: string, prefs: Partial<PreferenciasModelo>): void {
  if (!storageDisponivel()) return;
  try {
    const atual = carregarPreferencias(assinatura) ?? {};
    window.localStorage.setItem(chave(assinatura), JSON.stringify({ ...atual, ...prefs }));
  } catch {
    // Quota excedida ou storage bloqueado: falha silenciosamente, a UI segue
    // funcionando em memória (só não persiste entre sessões).
  }
}

export function limparPreferencias(assinatura: string): void {
  if (!storageDisponivel()) return;
  try {
    window.localStorage.removeItem(chave(assinatura));
  } catch {
    /* ignorado */
  }
}
