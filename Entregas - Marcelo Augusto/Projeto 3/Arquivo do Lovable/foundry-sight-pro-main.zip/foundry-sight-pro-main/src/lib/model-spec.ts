import { z } from "zod";
import {
  parseOnnxMetadata,
  parsePythonDictLike,
  type OnnxModelMetadata,
  type OnnxDim,
} from "./onnx-metadata";
import { REGRA_EXEMPLO_PADRAO, slug } from "./decision-rules";

// ---------------------------------------------------------------------------
// Config JSON opcional (arquivo à parte que acompanha o .onnx). Todos os
// campos são opcionais: o que não vier daqui é preenchido a partir dos
// metadata_props do próprio .onnx (quando o exportador os grava — Ultralytics
// YOLO, notebooks PyTorch com metadata_props manuais, etc.) e, na falta de
// ambos, com valores genéricos derivados apenas da forma dos tensores.
// ---------------------------------------------------------------------------
export const ModeloConfigSchema = z
  .object({
    nome_problema: z.string().optional(), // ex.: "Buraco na via"
    nome_modelo: z.string().optional(), // ex.: "YOLO11n"
    classes: z.union([z.array(z.string()), z.record(z.string(), z.string())]).optional(),
    metricas: z
      .object({
        map50: z.number().optional(),
        map50_95: z.number().optional(),
        epoca: z.union([z.number(), z.string()]).optional(),
      })
      .partial()
      .optional(),
    entrada: z
      .object({
        formato: z.enum(["NCHW", "NHWC"]).optional(),
        tipo_dado: z.string().optional(), // "RGB" | "GRAY"
        preprocessamento: z.enum(["letterbox", "resize"]).optional(),
        normalizacao: z
          .object({
            media: z.union([z.number(), z.array(z.number())]),
            desvio: z.union([z.number(), z.array(z.number())]),
          })
          .optional(),
      })
      .partial()
      .optional(),
    saida: z
      .object({
        descricao: z.string().optional(),
      })
      .partial()
      .optional(),
    origem: z
      .object({
        arquivo: z.string().optional(),
        fonte: z.string().optional(),
        texto: z.string().optional(), // linha livre, ex.: "best.pt · roboflow kartik-.../v1"
      })
      .partial()
      .optional(),
    exportado_em: z.string().optional(),
    confianca_minima_padrao: z.number().min(0).max(1).optional(),
    regras_decisao: z.string().optional(), // texto multi-linha, ver decision-rules.ts
  })
  .partial();

export type ModeloConfig = z.infer<typeof ModeloConfigSchema>;

export interface ValidatedConfig {
  config: ModeloConfig | null;
  erros: string[]; // problemas de sintaxe/schema, não bloqueiam — apenas o config é ignorado nos campos ruins
}

export function validarConfigJson(texto: string): ValidatedConfig {
  let bruto: unknown;
  try {
    bruto = JSON.parse(texto);
  } catch (e) {
    return {
      config: null,
      erros: [`JSON de configuração inválido: ${e instanceof Error ? e.message : String(e)}`],
    };
  }
  const resultado = ModeloConfigSchema.safeParse(bruto);
  if (!resultado.success) {
    const erros = resultado.error.issues.map(
      (i) => `Config: campo "${i.path.join(".") || "(raiz)"}" — ${i.message}`,
    );
    // Ainda tentamos aproveitar o que deu certo, fazendo um parse permissivo campo a campo.
    return { config: ModeloConfigSchema.partial().safeParse(bruto).data ?? null, erros };
  }
  return { config: resultado.data, erros: [] };
}

// ---------------------------------------------------------------------------
// ModelSpec: a representação única e agnóstica que a UI consome, resultado
// da fusão config.json > metadata_props do .onnx > forma dos tensores >
// valores genéricos de último recurso.
// ---------------------------------------------------------------------------

export type FormatoEntrada = "NCHW" | "NHWC" | "desconhecido";
export type TipoPreprocessamento = "letterbox" | "resize";

export interface EntradaSpec {
  tensorName: string;
  formato: FormatoEntrada;
  largura: number;
  altura: number;
  canais: number;
  dtype: string;
  preprocessamento: TipoPreprocessamento;
  normalizacao?: { media: number[]; desvio: number[] } | undefined;
}

export interface SaidaSpec {
  nomes: string[];
  descricao?: string | undefined;
}

export interface ModelSpec {
  nomeProblema: string;
  nomeModelo: string;
  producer?: string | undefined;
  producerVersion?: string | undefined;
  metricas?:
    | {
        map50?: number | undefined;
        map50_95?: number | undefined;
        epoca?: number | string | undefined;
      }
    | undefined;
  classes: string[];
  classesOrigem: "config" | "onnx_metadata" | "inferido_generico";
  entrada: EntradaSpec;
  saida: SaidaSpec;
  origemTexto?: string | undefined;
  exportadoEm?: string | undefined;
  confiancaMinimaPadrao: number;
  regrasDecisaoTextoPadrao: string;
  avisos: string[];
}

function numOrUndef(v: unknown): number | undefined {
  const n = typeof v === "string" ? Number(v) : (v as number);
  return typeof n === "number" && Number.isFinite(n) ? n : undefined;
}

function classesFromRecordOrArray(
  v: string[] | Record<string, string> | undefined,
): string[] | null {
  if (!v) return null;
  if (Array.isArray(v)) return v.length ? v : null;
  const entries = Object.entries(v);
  if (!entries.length) return null;
  const maxIdx = Math.max(...entries.map(([k]) => Number(k)).filter((n) => Number.isFinite(n)));
  const arr: string[] = new Array(maxIdx + 1).fill("");
  for (const [k, val] of entries) {
    const idx = Number(k);
    if (Number.isFinite(idx) && idx >= 0) arr[idx] = val;
  }
  return arr.some((c) => !c) ? entries.map(([, val]) => val) : arr;
}

/** Tenta achar dimensões conhecidas (altura/largura/canais) num shape de entrada [N,C,H,W] ou [N,H,W,C]. */
function inferirEntradaDoShape(shape: OnnxDim[]): {
  formato: FormatoEntrada;
  largura: number;
  altura: number;
  canais: number;
  avisos: string[];
} {
  const avisos: string[] = [];
  const nums = shape.map((d) => (typeof d === "number" ? d : undefined));
  if (shape.length === 4) {
    const [, d1, d2, d3] = nums;
    // NCHW: canal (1 ou 3) na posição 1
    if (d1 === 1 || d1 === 3) {
      return { formato: "NCHW", canais: d1, altura: d2 ?? 640, largura: d3 ?? 640, avisos };
    }
    // NHWC: canal na posição 3
    if (d3 === 1 || d3 === 3) {
      return { formato: "NHWC", canais: d3, altura: d1 ?? 640, largura: d2 ?? 640, avisos };
    }
    avisos.push(
      `Não foi possível determinar com certeza se o formato de entrada é NCHW ou NHWC a partir da forma [${shape.join(", ")}]; assumindo NCHW com 3 canais (RGB).`,
    );
    return { formato: "NCHW", canais: 3, altura: d2 ?? 640, largura: d3 ?? 640, avisos };
  }
  avisos.push(
    `Entrada com ${shape.length} dimensões (esperado 4: lote/canal/altura/largura). Usando 640×640 RGB como padrão genérico.`,
  );
  return { formato: "desconhecido", canais: 3, altura: 640, largura: 640, avisos };
}

export interface ConstruirModelSpecInput {
  onnxMeta: OnnxModelMetadata;
  config: ModeloConfig | null;
  nomeArquivo: string;
}

/**
 * Funde metadados do .onnx com o config.json opcional numa única ModelSpec.
 * Nunca lança: qualquer inconsistência vira uma entrada em `avisos` e um
 * valor padrão razoável é usado no lugar, para que o app sempre consiga
 * exibir *algo* e tentar rodar inferência, mesmo com metadados incompletos.
 */
export function construirModelSpec({
  onnxMeta,
  config,
  nomeArquivo,
}: ConstruirModelSpecInput): ModelSpec {
  const avisos: string[] = [];
  const meta = onnxMeta.metadataProps ?? {};

  // ---- entrada ----
  const entradaTensor = onnxMeta.inputs[0];
  if (onnxMeta.inputs.length > 1) {
    avisos.push(
      `O modelo declara ${onnxMeta.inputs.length} tensores de entrada (${onnxMeta.inputs.map((i) => i.name).join(", ")}); usando apenas o primeiro ("${entradaTensor?.name}"). Modelos com múltiplas entradas (ex.: imagem + máscara) não são suportados automaticamente.`,
    );
  }
  const shapeInferido = inferirEntradaDoShape(entradaTensor?.shape ?? []);
  avisos.push(...shapeInferido.avisos);

  const formatoConfig = config?.entrada?.formato;
  const canaisFinal =
    config?.entrada?.tipo_dado?.toUpperCase() === "GRAY"
      ? 1
      : config?.entrada?.tipo_dado?.toUpperCase() === "RGB"
        ? 3
        : shapeInferido.canais;

  let normalizacao: EntradaSpec["normalizacao"];
  if (config?.entrada?.normalizacao) {
    const m = config.entrada.normalizacao.media;
    const d = config.entrada.normalizacao.desvio;
    normalizacao = {
      media: Array.isArray(m) ? m : new Array(canaisFinal).fill(m),
      desvio: Array.isArray(d) ? d : new Array(canaisFinal).fill(d),
    };
  } else if (meta["normalizacao_media"] && meta["normalizacao_desvio"]) {
    const m = numOrUndef(meta["normalizacao_media"]);
    const d = numOrUndef(meta["normalizacao_desvio"]);
    if (m !== undefined && d !== undefined)
      normalizacao = {
        media: new Array(canaisFinal).fill(m),
        desvio: new Array(canaisFinal).fill(d),
      };
  }

  const entrada: EntradaSpec = {
    tensorName: entradaTensor?.name ?? "input",
    formato: formatoConfig ?? shapeInferido.formato,
    largura: shapeInferido.largura,
    altura: shapeInferido.altura,
    canais: canaisFinal,
    dtype: entradaTensor?.dtype ?? "float32",
    preprocessamento:
      config?.entrada?.preprocessamento ??
      (canaisFinal === 3 && shapeInferido.largura === shapeInferido.altura
        ? "letterbox"
        : "resize"),
    normalizacao,
  };
  if (entrada.dtype !== "float32") {
    avisos.push(
      `O tensor de entrada é do tipo "${entrada.dtype}", não float32. Modelos quantizados (int8/uint8) têm suporte limitado — os resultados podem ficar incorretos.`,
    );
  }

  // ---- saída ----
  const saida: SaidaSpec = {
    nomes: onnxMeta.outputs.map((o) => o.name),
    descricao: config?.saida?.descricao ?? meta["saida"],
  };

  // ---- classes ----
  let classes: string[] | null = classesFromRecordOrArray(config?.classes);
  let classesOrigem: ModelSpec["classesOrigem"] = "config";
  if (!classes) {
    const viaJson = parsePythonDictLike(meta["classes"] ?? meta["names"]);
    classes = viaJson ? classesFromRecordOrArray(viaJson as Record<string, string>) : null;
    classesOrigem = "onnx_metadata";
  }
  if (!classes || classes.length === 0) {
    // Última tentativa: inferir a quantidade de classes a partir da forma da
    // saída (não temos como saber os *nomes*, então geramos rótulos genéricos).
    const nOutClasses = inferirQuantidadeClassesDoOutput(onnxMeta);
    classes = Array.from({ length: nOutClasses ?? 2 }, (_, i) => `classe_${i}`);
    classesOrigem = "inferido_generico";
    avisos.push(
      `Não foi possível encontrar os nomes das classes (nem no config.json nem nos metadados do .onnx). Usando rótulos genéricos (${classes.join(", ")}) — carregue um config.json com o campo "classes" para nomes reais.`,
    );
  }

  // ---- métricas / origem / nomes ----
  const nomeModelo =
    config?.nome_modelo ??
    meta["nome_modelo"] ??
    onnxMeta.graphName ??
    nomeArquivo.replace(/\.onnx$/i, "");
  const nomeProblema =
    config?.nome_problema ??
    meta["nome_problema"] ??
    meta["projeto"] ??
    classes[classes.length - 1] ??
    nomeModelo;

  const metricas = {
    map50:
      config?.metricas?.map50 ??
      numOrUndef(meta["map50"] ?? meta["mAP50"] ?? meta["metrics/mAP50(B)"]),
    map50_95:
      config?.metricas?.map50_95 ??
      numOrUndef(meta["map50_95"] ?? meta["mAP50-95"] ?? meta["metrics/mAP50-95(B)"]),
    epoca: config?.metricas?.epoca ?? meta["epoca"] ?? meta["epoch"] ?? meta["melhor_epoca"],
  };
  const temMetricas =
    metricas.map50 !== undefined || metricas.map50_95 !== undefined || metricas.epoca !== undefined;

  const origemTexto = config?.origem?.texto ?? (meta["origem"] ? meta["origem"] : undefined);
  const exportadoEm = config?.exportado_em ?? meta["date"] ?? meta["exportado_em"];

  const confiancaMinimaPadrao =
    config?.confianca_minima_padrao ?? numOrUndef(meta["confianca_minima_padrao"]) ?? 0.35;

  const classePrincipal =
    config?.metricas?.map50 !== undefined || classesOrigem !== "inferido_generico"
      ? classes[classes.length - 1]
      : classes[0];
  const regrasDecisaoTextoPadrao =
    config?.regras_decisao ?? REGRA_EXEMPLO_PADRAO(classePrincipal ?? classes[0] ?? "classe_0");

  return {
    nomeProblema,
    nomeModelo,
    producer: onnxMeta.producerName,
    producerVersion: onnxMeta.producerVersion,
    metricas: temMetricas ? metricas : undefined,
    classes,
    classesOrigem,
    entrada,
    saida,
    origemTexto,
    exportadoEm,
    confiancaMinimaPadrao: Math.min(1, Math.max(0, confiancaMinimaPadrao)),
    regrasDecisaoTextoPadrao,
    avisos,
  };
}

function inferirQuantidadeClassesDoOutput(onnxMeta: OnnxModelMetadata): number | undefined {
  const out = onnxMeta.outputs[0];
  if (!out) return undefined;
  const dims = out.shape.filter((d): d is number => typeof d === "number");
  if (out.shape.length === 1 || out.shape.length === 0) return 2; // escalar por imagem -> assume binário
  if (out.shape.length === 2 && dims.length >= 1) return dims[dims.length - 1];
  if (out.shape.length === 3) {
    // heurística p/ export estilo YOLO: um dos eixos é (4 + nc) ou (5 + nc)
    return undefined; // decidido em tempo de execução por universal-inference.ts (usa mais contexto: nc candidato vs. contagem de caixas)
  }
  return undefined;
}

export function assinaturaModelo(nomeArquivo: string, tamanhoBytes: number): string {
  return `${slug(nomeArquivo)}_${tamanhoBytes}`;
}
