// Suporte a upload de um .zip contendo o .onnx (e opcionalmente um config
// .json) — por exemplo, o pacote exportado do Lovable já editado. Usa JSZip
// (leve, puro JS, sem dependências nativas) em vez de um parser de ZIP feito
// à mão: descompactação DEFLATE corretamente é bem mais arriscado de
// reimplementar do que os outros parsers deste projeto (protobuf, expressões).

import JSZip from "jszip";

export interface ArquivosExtraidos {
  onnx: { nome: string; bytes: Uint8Array } | null;
  config: { nome: string; texto: string } | null;
  avisos: string[];
}

export async function extrairDeZip(arquivo: File): Promise<ArquivosExtraidos> {
  const avisos: string[] = [];
  let zip: JSZip;
  try {
    zip = await JSZip.loadAsync(arquivo);
  } catch (e) {
    throw new Error(
      `Não foi possível abrir "${arquivo.name}" como .zip (arquivo corrompido ou não é um zip válido): ${e instanceof Error ? e.message : String(e)}`,
    );
  }

  const entradas = Object.values(zip.files).filter((f) => !f.dir);
  const onnxEntradas = entradas.filter((f) => f.name.toLowerCase().endsWith(".onnx"));
  const jsonEntradas = entradas.filter((f) => f.name.toLowerCase().endsWith(".json"));

  if (onnxEntradas.length === 0) {
    throw new Error(
      `Nenhum arquivo .onnx encontrado dentro de "${arquivo.name}". Verifique se o modelo foi incluído no zip.`,
    );
  }
  if (onnxEntradas.length > 1) {
    avisos.push(
      `O zip contém ${onnxEntradas.length} arquivos .onnx (${onnxEntradas.map((f) => f.name).join(", ")}); usando apenas o primeiro ("${onnxEntradas[0]!.name}"). Envie um zip com um único modelo por vez.`,
    );
  }
  const onnxEntrada = onnxEntradas[0]!;
  const bytes = await onnxEntrada.async("uint8array");

  let config: ArquivosExtraidos["config"] = null;
  if (jsonEntradas.length > 0) {
    // Prioriza arquivos com nome sugestivo de configuração, senão pega o primeiro .json.
    const preferida =
      jsonEntradas.find((f) => /config/i.test(f.name)) ??
      jsonEntradas.find(
        (f) =>
          f.name.replace(/\.json$/i, "").toLowerCase() ===
          onnxEntrada.name.replace(/\.onnx$/i, "").toLowerCase(),
      ) ??
      jsonEntradas[0]!;
    if (jsonEntradas.length > 1) {
      avisos.push(
        `O zip contém ${jsonEntradas.length} arquivos .json; usando "${preferida.name}" como configuração do modelo.`,
      );
    }
    const texto = await preferida.async("text");
    config = { nome: preferida.name, texto };
  }

  return { onnx: { nome: onnxEntrada.name, bytes }, config, avisos };
}
