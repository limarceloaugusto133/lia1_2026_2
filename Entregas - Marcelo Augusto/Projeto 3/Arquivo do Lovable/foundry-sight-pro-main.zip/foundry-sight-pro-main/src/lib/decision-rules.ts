// Motor de regras de decisão pós-inferência.
//
// Formato editável pelo usuário (uma regra por linha):
//   Rótulo exibido | expressão booleana
// Exemplo (replica o card de referência):
//   Buraco na via | buraco >= 0.5
//   Verificar | buraco >= 0.3 && buraco < 0.5
//
// A expressão pode usar: nomes de classe (normalizados — ver `slug`),
// números, parênteses e os operadores >= <= == != > < && || ! + - * /.
// Deliberadamente NÃO usamos eval()/new Function(): o texto vem do usuário
// (ou de um arquivo de config carregado) e um parser dedicado nos dá tanto
// segurança quanto mensagens de erro precisas (linha/coluna) quando a regra
// está malformada.

export type RuleTone = "alerta" | "atencao" | "ok" | "neutro";

export interface DecisionRule {
  linha: number; // 1-based, para mensagens de erro
  rotulo: string;
  expressaoTexto: string;
  ast: Expr;
  tom: RuleTone;
}

export interface ParsedRules {
  regras: DecisionRule[];
  erros: string[]; // linhas que não puderam ser interpretadas (não bloqueia as demais)
}

export interface DecisionResult {
  rotulo: string;
  tom: RuleTone;
  expressaoTexto: string;
}

// ---------- normalização de identificadores ----------

/** Converte um nome de classe livre ("Buraco na Via") num identificador estável ("buraco_na_via"). */
export function slug(nome: string): string {
  return (
    nome
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "") // remove acentos
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "") || "classe"
  );
}

// ---------- tokenizer ----------

type TokenType = "num" | "ident" | "op" | "lparen" | "rparen" | "eof";
interface Token {
  type: TokenType;
  value: string;
  pos: number;
}

const OPERATORS = [">=", "<=", "==", "!=", "&&", "||", ">", "<", "!", "+", "-", "*", "/"];

function tokenize(src: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === undefined) break;
    if (/\s/.test(c)) {
      i++;
      continue;
    }
    if (c === "(") {
      tokens.push({ type: "lparen", value: c, pos: i });
      i++;
      continue;
    }
    if (c === ")") {
      tokens.push({ type: "rparen", value: c, pos: i });
      i++;
      continue;
    }
    if (/[0-9.]/.test(c)) {
      let j = i;
      while (j < src.length && /[0-9.]/.test(src[j] ?? "")) j++;
      const raw = src.slice(i, j);
      if (!/^\d*\.?\d+$/.test(raw)) throw new RuleSyntaxError(`Número inválido "${raw}"`, i);
      tokens.push({ type: "num", value: raw, pos: i });
      i = j;
      continue;
    }
    if (/[a-zA-Z_]/.test(c)) {
      let j = i;
      while (j < src.length && /[a-zA-Z0-9_]/.test(src[j] ?? "")) j++;
      tokens.push({ type: "ident", value: src.slice(i, j), pos: i });
      i = j;
      continue;
    }
    const two = src.slice(i, i + 2);
    if (OPERATORS.includes(two)) {
      tokens.push({ type: "op", value: two, pos: i });
      i += 2;
      continue;
    }
    if (OPERATORS.includes(c)) {
      tokens.push({ type: "op", value: c, pos: i });
      i++;
      continue;
    }
    throw new RuleSyntaxError(`Caractere inesperado "${c}"`, i);
  }
  tokens.push({ type: "eof", value: "", pos: src.length });
  return tokens;
}

export class RuleSyntaxError extends Error {
  constructor(
    message: string,
    public pos: number,
  ) {
    super(message);
    this.name = "RuleSyntaxError";
  }
}

// ---------- AST + parser (recursive descent, precedência padrão) ----------

export type Expr =
  | { kind: "num"; value: number }
  | { kind: "var"; name: string }
  | { kind: "unary"; op: "!" | "-"; expr: Expr }
  | { kind: "bin"; op: string; left: Expr; right: Expr };

class Parser {
  private i = 0;
  constructor(private tokens: Token[]) {}
  private peek() {
    return this.tokens[this.i] as Token;
  }
  private next() {
    return this.tokens[this.i++] as Token;
  }
  private expect(type: TokenType, value?: string) {
    const t = this.peek();
    if (t.type !== type || (value !== undefined && t.value !== value)) {
      throw new RuleSyntaxError(
        `Esperado "${value ?? type}", encontrado "${t.value || "fim da expressão"}"`,
        t.pos,
      );
    }
    return this.next();
  }

  parseExpr(): Expr {
    const e = this.parseOr();
    this.expect("eof");
    return e;
  }
  private parseOr(): Expr {
    let left = this.parseAnd();
    while (this.peek().type === "op" && this.peek().value === "||") {
      this.next();
      left = { kind: "bin", op: "||", left, right: this.parseAnd() };
    }
    return left;
  }
  private parseAnd(): Expr {
    let left = this.parseComparison();
    while (this.peek().type === "op" && this.peek().value === "&&") {
      this.next();
      left = { kind: "bin", op: "&&", left, right: this.parseComparison() };
    }
    return left;
  }
  private parseComparison(): Expr {
    let left = this.parseAdditive();
    while (
      this.peek().type === "op" &&
      [">=", "<=", "==", "!=", ">", "<"].includes(this.peek().value)
    ) {
      const op = this.next().value;
      left = { kind: "bin", op, left, right: this.parseAdditive() };
    }
    return left;
  }
  private parseAdditive(): Expr {
    let left = this.parseMultiplicative();
    while (this.peek().type === "op" && (this.peek().value === "+" || this.peek().value === "-")) {
      const op = this.next().value;
      left = { kind: "bin", op, left, right: this.parseMultiplicative() };
    }
    return left;
  }
  private parseMultiplicative(): Expr {
    let left = this.parseUnary();
    while (this.peek().type === "op" && (this.peek().value === "*" || this.peek().value === "/")) {
      const op = this.next().value;
      left = { kind: "bin", op, left, right: this.parseUnary() };
    }
    return left;
  }
  private parseUnary(): Expr {
    if (this.peek().type === "op" && (this.peek().value === "!" || this.peek().value === "-")) {
      const op = this.next().value as "!" | "-";
      return { kind: "unary", op, expr: this.parseUnary() };
    }
    return this.parsePrimary();
  }
  private parsePrimary(): Expr {
    const t = this.peek();
    if (t.type === "num") {
      this.next();
      return { kind: "num", value: Number(t.value) };
    }
    if (t.type === "ident") {
      this.next();
      return { kind: "var", name: t.value };
    }
    if (t.type === "lparen") {
      this.next();
      const e = this.parseOr();
      this.expect("rparen");
      return e;
    }
    throw new RuleSyntaxError(`Token inesperado "${t.value || "fim"}"`, t.pos);
  }
}

export function parseExpression(src: string): Expr {
  return new Parser(tokenize(src)).parseExpr();
}

// ---------- avaliação segura (sem eval/Function) ----------

export function evaluateExpression(ast: Expr, scores: Record<string, number>): number {
  switch (ast.kind) {
    case "num":
      return ast.value;
    case "var": {
      const v = scores[ast.name];
      if (v === undefined) {
        throw new RuleSyntaxError(
          `Classe/variável "${ast.name}" não existe neste modelo. Classes disponíveis: ${Object.keys(scores).join(", ") || "(nenhuma)"}`,
          -1,
        );
      }
      return v;
    }
    case "unary": {
      const v = evaluateExpression(ast.expr, scores);
      return ast.op === "!" ? (v === 0 ? 1 : 0) : -v;
    }
    case "bin": {
      const l = evaluateExpression(ast.left, scores);
      const r = evaluateExpression(ast.right, scores);
      switch (ast.op) {
        case "&&":
          return l !== 0 && r !== 0 ? 1 : 0;
        case "||":
          return l !== 0 || r !== 0 ? 1 : 0;
        case ">=":
          return l >= r ? 1 : 0;
        case "<=":
          return l <= r ? 1 : 0;
        case ">":
          return l > r ? 1 : 0;
        case "<":
          return l < r ? 1 : 0;
        case "==":
          return l === r ? 1 : 0;
        case "!=":
          return l !== r ? 1 : 0;
        case "+":
          return l + r;
        case "-":
          return l - r;
        case "*":
          return l * r;
        case "/":
          return r === 0 ? NaN : l / r;
        default:
          throw new RuleSyntaxError(`Operador desconhecido "${ast.op}"`, -1);
      }
    }
  }
}

function inferTone(rotulo: string, index: number): RuleTone {
  const lower = rotulo.toLowerCase();
  if (
    /(defeito|falha|reprovad|anomalia|alerta|buraco|risco|ncg|não conforme|nao conforme)/.test(
      lower,
    )
  )
    return "alerta";
  if (/(verificar|revisar|atenç|atenc|d[uú]vida|incerto|zona cinza)/.test(lower)) return "atencao";
  if (/(ok|conforme|aprovad|normal|sem defeito)/.test(lower)) return "ok";
  return index === 0 ? "alerta" : "neutro";
}

/**
 * Interpreta o texto de regras (uma por linha, "rótulo | expressão").
 * Linhas vazias e linhas iniciadas com "#" (comentário) são ignoradas.
 * Nunca lança: linhas malformadas viram entradas em `erros` e são puladas,
 * para que uma regra com erro de digitação não derrube as demais.
 */
export function parseDecisionRules(texto: string): ParsedRules {
  const regras: DecisionRule[] = [];
  const erros: string[] = [];
  const linhas = texto.split("\n");

  linhas.forEach((linhaRaw, idx) => {
    const linha = linhaRaw.trim();
    if (!linha || linha.startsWith("#")) return;
    const sep = linha.indexOf("|");
    if (sep === -1) {
      erros.push(
        `Linha ${idx + 1}: use o formato "rótulo | expressão" (ex.: "Buraco na via | buraco >= 0.5"). Linha ignorada.`,
      );
      return;
    }
    const rotulo = linha.slice(0, sep).trim();
    const expressaoTexto = linha.slice(sep + 1).trim();
    if (!rotulo) {
      erros.push(`Linha ${idx + 1}: rótulo vazio antes do "|". Linha ignorada.`);
      return;
    }
    if (!expressaoTexto) {
      erros.push(`Linha ${idx + 1}: expressão vazia depois do "|". Linha ignorada.`);
      return;
    }
    try {
      const ast = parseExpression(expressaoTexto);
      regras.push({
        linha: idx + 1,
        rotulo,
        expressaoTexto,
        ast,
        tom: inferTone(rotulo, regras.length),
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      erros.push(`Linha ${idx + 1} ("${rotulo}"): ${msg}`);
    }
  });

  return { regras, erros };
}

/**
 * Avalia as regras em ordem e retorna a primeira cujo resultado seja
 * "verdadeiro" (!= 0). Se nenhuma regra bater, retorna null (chamador deve
 * tratar isso como "sem decisão aplicável" e mostrar as pontuações brutas).
 * Erros de avaliação de uma regra individual (ex.: variável inexistente)
 * não interrompem a checagem das demais regras.
 */
export function decidir(
  regras: DecisionRule[],
  scores: Record<string, number>,
): { resultado: DecisionResult | null; erros: string[] } {
  const erros: string[] = [];
  for (const regra of regras) {
    try {
      const v = evaluateExpression(regra.ast, scores);
      if (v !== 0 && !Number.isNaN(v)) {
        return {
          resultado: { rotulo: regra.rotulo, tom: regra.tom, expressaoTexto: regra.expressaoTexto },
          erros,
        };
      }
    } catch (e) {
      erros.push(
        `Regra "${regra.rotulo}" (linha ${regra.linha}): ${e instanceof Error ? e.message : String(e)}`,
      );
    }
  }
  return { resultado: null, erros };
}

export const REGRA_EXEMPLO_PADRAO = (classePrincipal: string) =>
  `${classePrincipal} | ${slug(classePrincipal)} >= 0.5\nVerificar | ${slug(classePrincipal)} >= 0.3 && ${slug(classePrincipal)} < 0.5`;
