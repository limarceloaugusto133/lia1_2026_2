// Leitor mínimo do formato protobuf usado pelos arquivos .onnx.
//
// Por quê um parser "na mão" em vez de uma lib de protobuf? Precisamos de
// pouquíssimos campos (nome/versão do produtor, entradas/saídas do grafo,
// metadata_props) e uma dependência completa de protobuf.js + os .proto do
// ONNX custam vários MB de bundle para um app que roda no navegador. O
// formato binário do ONNX (varint + length-delimited, ver onnx.proto) é
// estável entre versões, então um leitor de baixo nível é seguro e agnóstico
// ao "tipo" de modelo — ele não sabe (nem precisa saber) se é um classificador
// ou um detector; só lê a estrutura do grafo.
//
// Isso é INDEPENDENTE do onnxruntime-web: extrai metadados sem instanciar
// nenhuma sessão de inferência, então funciona mesmo com modelos que o
// runtime instalado não consiga executar, e é bem mais rápido para só exibir
// informações (o modelo pode ter dezenas de MB).

const WIRE_VARINT = 0;
const WIRE_64BIT = 1;
const WIRE_LEN = 2;
const WIRE_32BIT = 5;

export class OnnxParseError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "OnnxParseError";
  }
}

class ProtoReader {
  pos: number;
  constructor(
    private bytes: Uint8Array,
    start = 0,
    private end: number = bytes.length,
  ) {
    this.pos = start;
  }
  eof() {
    return this.pos >= this.end;
  }
  private readByte(): number {
    const b = this.bytes[this.pos++];
    if (b === undefined)
      throw new OnnxParseError("Fim inesperado do arquivo (truncado ou corrompido).");
    return b;
  }
  readVarint(): bigint {
    let result = 0n;
    let shift = 0n;
    for (;;) {
      const b = this.readByte();
      result |= BigInt(b & 0x7f) << shift;
      if ((b & 0x80) === 0) break;
      shift += 7n;
      if (shift > 70n) throw new OnnxParseError("Varint inválido (protobuf corrompido).");
    }
    return result;
  }
  readTag(): { field: number; wireType: number } {
    const tag = Number(this.readVarint());
    return { field: tag >>> 3, wireType: tag & 0x7 };
  }
  readLenDelim(): Uint8Array {
    const len = Number(this.readVarint());
    if (!Number.isFinite(len) || len < 0 || this.pos + len > this.end) {
      throw new OnnxParseError(
        "Tamanho de campo inconsistente (arquivo corrompido ou não é um .onnx válido).",
      );
    }
    const slice = this.bytes.subarray(this.pos, this.pos + len);
    this.pos += len;
    return slice;
  }
  readString(): string {
    return new TextDecoder("utf-8", { fatal: false }).decode(this.readLenDelim());
  }
  skip(wireType: number) {
    switch (wireType) {
      case WIRE_VARINT:
        this.readVarint();
        break;
      case WIRE_64BIT:
        this.pos += 8;
        break;
      case WIRE_LEN:
        this.readLenDelim();
        break;
      case WIRE_32BIT:
        this.pos += 4;
        break;
      default:
        throw new OnnxParseError(
          `Wire type de protobuf desconhecido (${wireType}) — formato não suportado.`,
        );
    }
  }
}

export type OnnxDim = number | string; // string = dimensão simbólica (ex.: "batch", "N")

export interface OnnxValueInfo {
  name: string;
  dtype: string;
  shape: OnnxDim[];
}

export interface OnnxModelMetadata {
  irVersion?: number | undefined;
  producerName?: string | undefined;
  producerVersion?: string | undefined;
  domain?: string | undefined;
  modelVersion?: number | undefined;
  docString?: string | undefined;
  graphName?: string | undefined;
  inputs: OnnxValueInfo[];
  outputs: OnnxValueInfo[];
  /** metadata_props "crua" (string -> string), como o exportador gravou */
  metadataProps: Record<string, string>;
}

function readDimension(bytes: Uint8Array): OnnxDim {
  const r = new ProtoReader(bytes);
  let dimValue: number | undefined;
  let dimParam: string | undefined;
  while (!r.eof()) {
    const { field, wireType } = r.readTag();
    if (field === 1 && wireType === WIRE_VARINT) dimValue = Number(r.readVarint());
    else if (field === 2 && wireType === WIRE_LEN) dimParam = r.readString();
    else r.skip(wireType);
  }
  if (dimValue !== undefined) return dimValue;
  if (dimParam !== undefined) return dimParam;
  return "?";
}

function readTensorShape(bytes: Uint8Array): OnnxDim[] {
  const r = new ProtoReader(bytes);
  const dims: OnnxDim[] = [];
  while (!r.eof()) {
    const { field, wireType } = r.readTag();
    if (field === 1 && wireType === WIRE_LEN) dims.push(readDimension(r.readLenDelim()));
    else r.skip(wireType);
  }
  return dims;
}

function readTypeProto(bytes: Uint8Array): { elemType?: number | undefined; shape: OnnxDim[] } {
  const r = new ProtoReader(bytes);
  let elemType: number | undefined;
  let shape: OnnxDim[] = [];
  while (!r.eof()) {
    const { field, wireType } = r.readTag();
    if (field === 1 && wireType === WIRE_LEN) {
      const tr = new ProtoReader(r.readLenDelim());
      while (!tr.eof()) {
        const t2 = tr.readTag();
        if (t2.field === 1 && t2.wireType === WIRE_VARINT) elemType = Number(tr.readVarint());
        else if (t2.field === 2 && t2.wireType === WIRE_LEN)
          shape = readTensorShape(tr.readLenDelim());
        else tr.skip(t2.wireType);
      }
    } else {
      r.skip(wireType);
    }
  }
  return { elemType, shape };
}

function readValueInfo(bytes: Uint8Array): OnnxValueInfo {
  const r = new ProtoReader(bytes);
  let name = "";
  let elemType: number | undefined;
  let shape: OnnxDim[] = [];
  while (!r.eof()) {
    const { field, wireType } = r.readTag();
    if (field === 1 && wireType === WIRE_LEN) name = r.readString();
    else if (field === 2 && wireType === WIRE_LEN) {
      const t = readTypeProto(r.readLenDelim());
      elemType = t.elemType;
      shape = t.shape;
    } else r.skip(wireType);
  }
  return {
    name,
    dtype:
      ELEM_TYPE_NAMES[elemType ?? -1] ??
      (elemType !== undefined ? `tipo(${elemType})` : "desconhecido"),
    shape,
  };
}

function readStringStringEntry(bytes: Uint8Array): { key: string; value: string } {
  const r = new ProtoReader(bytes);
  let key = "";
  let value = "";
  while (!r.eof()) {
    const { field, wireType } = r.readTag();
    if (field === 1 && wireType === WIRE_LEN) key = r.readString();
    else if (field === 2 && wireType === WIRE_LEN) value = r.readString();
    else r.skip(wireType);
  }
  return { key, value };
}

function readGraph(bytes: Uint8Array): {
  name?: string | undefined;
  inputs: OnnxValueInfo[];
  outputs: OnnxValueInfo[];
} {
  const r = new ProtoReader(bytes);
  let name: string | undefined;
  const inputs: OnnxValueInfo[] = [];
  const outputs: OnnxValueInfo[] = [];
  while (!r.eof()) {
    const { field, wireType } = r.readTag();
    if (field === 2 && wireType === WIRE_LEN) name = r.readString();
    else if (field === 11 && wireType === WIRE_LEN) inputs.push(readValueInfo(r.readLenDelim()));
    else if (field === 12 && wireType === WIRE_LEN) outputs.push(readValueInfo(r.readLenDelim()));
    else r.skip(wireType);
  }
  return { name, inputs, outputs };
}

const ELEM_TYPE_NAMES: Record<number, string> = {
  1: "float32",
  2: "uint8",
  3: "int8",
  4: "uint16",
  5: "int16",
  6: "int32",
  7: "int64",
  8: "string",
  9: "bool",
  10: "float16",
  11: "float64",
  12: "uint32",
  13: "uint64",
  14: "complex64",
  15: "complex128",
  16: "bfloat16",
};

/**
 * Extrai metadados de um arquivo .onnx sem executá-lo. Lança OnnxParseError
 * com uma mensagem amigável (em pt-BR) para arquivos corrompidos/inválidos.
 */
export function parseOnnxMetadata(buffer: ArrayBuffer): OnnxModelMetadata {
  if (buffer.byteLength < 8) {
    throw new OnnxParseError("Arquivo pequeno demais para ser um modelo ONNX válido.");
  }
  const bytes = new Uint8Array(buffer);
  const r = new ProtoReader(bytes);

  let irVersion: number | undefined;
  let producerName: string | undefined;
  let producerVersion: string | undefined;
  let domain: string | undefined;
  let modelVersion: number | undefined;
  let docString: string | undefined;
  let graph:
    { name?: string | undefined; inputs: OnnxValueInfo[]; outputs: OnnxValueInfo[] } | undefined;
  const metadataProps: Record<string, string> = {};

  try {
    while (!r.eof()) {
      const { field, wireType } = r.readTag();
      if (field === 1 && wireType === WIRE_VARINT) irVersion = Number(r.readVarint());
      else if (field === 2 && wireType === WIRE_LEN) producerName = r.readString();
      else if (field === 3 && wireType === WIRE_LEN) producerVersion = r.readString();
      else if (field === 4 && wireType === WIRE_LEN) domain = r.readString();
      else if (field === 5 && wireType === WIRE_VARINT) modelVersion = Number(r.readVarint());
      else if (field === 6 && wireType === WIRE_LEN) docString = r.readString();
      else if (field === 7 && wireType === WIRE_LEN) graph = readGraph(r.readLenDelim());
      else if (field === 14 && wireType === WIRE_LEN) {
        const { key, value } = readStringStringEntry(r.readLenDelim());
        if (key) metadataProps[key] = value;
      } else r.skip(wireType);
    }
  } catch (e) {
    if (e instanceof OnnxParseError) throw e;
    throw new OnnxParseError(
      `Não foi possível interpretar o arquivo como ONNX (protobuf inválido ou corrompido): ${e instanceof Error ? e.message : String(e)}`,
    );
  }

  if (!graph) {
    throw new OnnxParseError(
      "O arquivo não contém um grafo de computação (GraphProto). Ele pode estar corrompido, truncado, ou não ser um ModelProto do ONNX.",
    );
  }
  if (graph.inputs.length === 0) {
    throw new OnnxParseError(
      "O modelo não declara nenhum tensor de entrada — não é possível rodar inferência nele.",
    );
  }
  if (graph.outputs.length === 0) {
    throw new OnnxParseError(
      "O modelo não declara nenhum tensor de saída — não é possível interpretar o resultado.",
    );
  }

  return {
    irVersion,
    producerName,
    producerVersion,
    domain,
    modelVersion,
    docString,
    graphName: graph.name,
    inputs: graph.inputs,
    outputs: graph.outputs,
    metadataProps,
  };
}

/**
 * Ferramentas como o Ultralytics YOLO gravam `metadata_props.names` como a
 * *repr* de um dict Python (ex.: "{0: 'buraco', 1: 'trinca'}"), não como
 * JSON válido (aspas simples, sem aspas nas chaves numéricas). Também aceita
 * JSON de verdade (chaves com aspas), que é o que outros exportadores usam.
 * Retorna null se não conseguir interpretar de nenhuma das duas formas —
 * quem chama deve tratar isso como "classes não encontradas" e cair no
 * fallback (ver model-spec.ts), nunca lançar.
 */
export function parsePythonDictLike(raw: string | undefined): Record<string, string> | null {
  if (!raw) return null;
  const text = raw.trim();
  if (!text) return null;
  try {
    const direct = JSON.parse(text);
    if (direct && typeof direct === "object") return direct as Record<string, string>;
  } catch {
    /* tenta o formato Python abaixo */
  }
  try {
    const jsonish = text.replace(/'/g, '"').replace(/(\{|,)\s*(\d+)\s*:/g, '$1"$2":');
    const parsed = JSON.parse(jsonish);
    if (parsed && typeof parsed === "object") return parsed as Record<string, string>;
  } catch {
    /* ignorado — retorna null abaixo */
  }
  return null;
}
