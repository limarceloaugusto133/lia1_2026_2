import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertOctagon,
  Cpu,
  FileJson,
  FileImage,
  ImagePlus,
  LoaderCircle,
  ScanLine,
  Settings2,
  TriangleAlert,
  Upload,
  FileArchive,
  RotateCcw,
  Moon,
  Sun,
  CircleHelp,
  Boxes,
  Image as ImageIcon,
  Layers3,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { ModelSpecCard } from "@/components/ModelSpecCard";
import { DetectionOverlay } from "@/components/DetectionOverlay";
import { parseOnnxMetadata, OnnxParseError, type OnnxModelMetadata } from "@/lib/onnx-metadata";
import {
  construirModelSpec,
  validarConfigJson,
  assinaturaModelo,
  type ModeloConfig,
  type ModelSpec,
} from "@/lib/model-spec";
import {
  criarSessaoDeBytes,
  preprocessarImagem,
  shapeDoTensorEntrada,
  decodificarSaida,
  ModeloInvalidoError,
  type ResultadoInferencia,
} from "@/lib/universal-inference";
import { parseDecisionRules, decidir, type DecisionResult } from "@/lib/decision-rules";
import { carregarPreferencias, salvarPreferencias, limparPreferencias } from "@/lib/model-store";
import { extrairDeZip } from "@/lib/zip-utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Inspetor Universal ONNX" },
      {
        name: "description",
        content: "Carregue qualquer modelo .onnx e rode inferência no navegador, sem hardcoding.",
      },
      { property: "og:title", content: "Inspetor Universal ONNX" },
      {
        property: "og:description",
        content: "Inspeção técnica de modelos ONNX e inferência de imagens diretamente no navegador.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: InspetorUniversal,
});

type EstadoModelo = "vazio" | "carregando" | "pronto" | "erro";
type EstadoInferencia = "ocioso" | "analisando" | "completo" | "erro";

interface SessaoOnnx {
  session: import("onnxruntime-web").InferenceSession;
}

function InspetorUniversal() {
  const [tema, setTema] = useState<"light" | "dark">("dark");
  const [temaPronto, setTemaPronto] = useState(false);
  const [arrastandoModelo, setArrastandoModelo] = useState(false);
  const [arrastandoImagem, setArrastandoImagem] = useState(false);
  const [visualizacao, setVisualizacao] = useState<"original" | "deteccoes">("deteccoes");

  useEffect(() => {
    let preferencia: "light" | "dark" = window.matchMedia("(prefers-color-scheme: dark)").matches
      ? "dark"
      : "light";
    try {
      const salva = window.localStorage.getItem("onnx-universal:tema");
      if (salva === "light" || salva === "dark") preferencia = salva;
    } catch {
      // A preferência do sistema continua valendo quando o armazenamento está indisponível.
    }
    setTema(preferencia);
    document.documentElement.classList.toggle("dark", preferencia === "dark");
    setTemaPronto(true);
  }, []);

  function alternarTema() {
    const proximo = tema === "dark" ? "light" : "dark";
    setTema(proximo);
    document.documentElement.classList.toggle("dark", proximo === "dark");
    try {
      window.localStorage.setItem("onnx-universal:tema", proximo);
    } catch {
      // A troca ainda funciona durante esta visita.
    }
  }
  // ---- modelo ----
  const [estadoModelo, setEstadoModelo] = useState<EstadoModelo>("vazio");
  const [erroModelo, setErroModelo] = useState<string | null>(null);
  const [onnxMeta, setOnnxMeta] = useState<OnnxModelMetadata | null>(null);
  const [config, setConfig] = useState<ModeloConfig | null>(null);
  const [configErros, setConfigErros] = useState<string[]>([]);
  const [nomeArquivoModelo, setNomeArquivoModelo] = useState<string>("");
  const [assinatura, setAssinatura] = useState<string>("");
  const [sessao, setSessao] = useState<SessaoOnnx | null>(null);
  const [erroSessao, setErroSessao] = useState<string | null>(null);

  const spec: ModelSpec | null = useMemo(() => {
    if (!onnxMeta) return null;
    return construirModelSpec({ onnxMeta, config, nomeArquivo: nomeArquivoModelo });
  }, [onnxMeta, config, nomeArquivoModelo]);

  // ---- parâmetros ajustáveis (persistidos por modelo) ----
  const [confiancaMinima, setConfiancaMinima] = useState(0.35);
  const [regrasTexto, setRegrasTexto] = useState("");
  const [editandoRegras, setEditandoRegras] = useState(false);

  useEffect(() => {
    if (!spec) return;
    const salvas = carregarPreferencias(assinatura);
    setConfiancaMinima(salvas?.confiancaMinima ?? spec.confiancaMinimaPadrao);
    setRegrasTexto(salvas?.regrasDecisaoTexto ?? spec.regrasDecisaoTextoPadrao);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [spec?.nomeModelo, assinatura]);

  useEffect(() => {
    if (!assinatura || !spec) return;
    salvarPreferencias(assinatura, { confiancaMinima, regrasDecisaoTexto: regrasTexto });
  }, [assinatura, confiancaMinima, regrasTexto, spec]);

  const regrasParsed = useMemo(() => parseDecisionRules(regrasTexto), [regrasTexto]);

  // ---- imagem + inferência ----
  const imgInputRef = useRef<HTMLInputElement>(null);
  const onnxInputRef = useRef<HTMLInputElement>(null);
  const zipInputRef = useRef<HTMLInputElement>(null);
  const configInputRef = useRef<HTMLInputElement>(null);

  const [imagemUrl, setImagemUrl] = useState<string | null>(null);
  const [imagemArquivo, setImagemArquivo] = useState<File | null>(null);
  const [imagemDims, setImagemDims] = useState<{ w: number; h: number } | null>(null);
  const [estadoInferencia, setEstadoInferencia] = useState<EstadoInferencia>("ocioso");
  const [resultado, setResultado] = useState<ResultadoInferencia | null>(null);
  const [erroInferencia, setErroInferencia] = useState<string | null>(null);
  const [tempoMs, setTempoMs] = useState<number | null>(null);

  useEffect(() => {
    return () => {
      if (imagemUrl?.startsWith("blob:")) URL.revokeObjectURL(imagemUrl);
    };
  }, [imagemUrl]);

  const decisao: DecisionResult | null = useMemo(() => {
    if (!resultado || resultado.tipo === "bruto") return null;
    return decidir(regrasParsed.regras, resultado.scores).resultado;
  }, [resultado, regrasParsed]);

  // ---------------------------------------------------------------------
  // Carregamento do modelo
  // ---------------------------------------------------------------------

  async function carregarModeloDeBytes(
    bytes: Uint8Array,
    nomeArquivo: string,
    configTextoOpcional?: string,
    avisosExtras: string[] = [],
  ) {
    setEstadoModelo("carregando");
    setErroModelo(null);
    setErroSessao(null);
    setSessao(null);
    setOnnxMeta(null);
    setResultado(null);
    setEstadoInferencia("ocioso");

    let meta: OnnxModelMetadata;
    try {
      meta = parseOnnxMetadata(
        bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer,
      );
    } catch (e) {
      const msg =
        e instanceof OnnxParseError
          ? e.message
          : `Falha inesperada ao ler o arquivo: ${e instanceof Error ? e.message : String(e)}`;
      setErroModelo(msg);
      setEstadoModelo("erro");
      toast.error("Não foi possível carregar o modelo", { description: msg });
      return;
    }

    let configValidado: ModeloConfig | null = null;
    let errosConfig: string[] = [];
    if (configTextoOpcional) {
      const r = validarConfigJson(configTextoOpcional);
      configValidado = r.config;
      errosConfig = r.erros;
    }

    setOnnxMeta(meta);
    setConfig(configValidado);
    setConfigErros([...avisosExtras, ...errosConfig]);
    setNomeArquivoModelo(nomeArquivo);
    setAssinatura(assinaturaModelo(nomeArquivo, bytes.byteLength));
    setEstadoModelo("pronto");
    toast.success("Modelo carregado", { description: `${nomeArquivo} está pronto para inspeção.` });

    // Sessão de inferência é criada em paralelo — se falhar, ainda mostramos
    // os metadados (útil mesmo que o motor não rode este modelo específico).
    try {
      const session = await criarSessaoDeBytes(bytes);
      setSessao({ session });
    } catch (e) {
      setErroSessao(
        e instanceof ModeloInvalidoError
          ? e.message
          : `Falha ao inicializar o motor de inferência: ${e instanceof Error ? e.message : String(e)}`,
      );
    }
  }

  async function handleOnnxSelecionado(file?: File) {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith(".onnx")) {
      setErroModelo(`"${file.name}" não parece ser um arquivo .onnx (extensão inesperada).`);
      setEstadoModelo("erro");
      toast.error("Arquivo incompatível", { description: "Selecione um modelo com extensão .onnx." });
      return;
    }
    const buf = await file.arrayBuffer();
    await carregarModeloDeBytes(new Uint8Array(buf), file.name);
  }

  async function handleZipSelecionado(file?: File) {
    if (!file) return;
    setEstadoModelo("carregando");
    setErroModelo(null);
    try {
      const extraido = await extrairDeZip(file);
      if (!extraido.onnx) throw new Error("O zip não contém um arquivo .onnx.");
      await carregarModeloDeBytes(
        extraido.onnx.bytes,
        extraido.onnx.nome,
        extraido.config?.texto,
        extraido.avisos,
      );
    } catch (e) {
      setErroModelo(e instanceof Error ? e.message : String(e));
      setEstadoModelo("erro");
      toast.error("Não foi possível abrir o pacote", {
        description: e instanceof Error ? e.message : String(e),
      });
    }
  }

  async function handleConfigSelecionado(file?: File) {
    if (!file || !onnxMeta) return;
    const texto = await file.text();
    const r = validarConfigJson(texto);
    setConfig(r.config);
    setConfigErros(r.erros);
    if (r.erros.length > 0) toast.warning("Configuração carregada com avisos");
    else toast.success("Configuração aplicada");
  }

  function resetarModelo() {
    if (assinatura) limparPreferencias(assinatura);
    setEstadoModelo("vazio");
    setOnnxMeta(null);
    setConfig(null);
    setSessao(null);
    setResultado(null);
    setErroModelo(null);
    setErroSessao(null);
  }

  // ---------------------------------------------------------------------
  // Imagem + inferência
  // ---------------------------------------------------------------------

  function escolherImagem(file?: File) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setErroInferencia(`"${file.name}" não é um arquivo de imagem.`);
      setEstadoInferencia("erro");
      toast.error("Arquivo incompatível", { description: "Selecione uma imagem válida." });
      return;
    }
    const url = URL.createObjectURL(file);
    setImagemUrl(url);
    setImagemArquivo(file);
    setResultado(null);
    setEstadoInferencia("ocioso");
    setErroInferencia(null);
    const img = new Image();
    img.onload = () => setImagemDims({ w: img.naturalWidth, h: img.naturalHeight });
    img.src = url;
    setVisualizacao("deteccoes");
    toast.success("Imagem pronta para inspeção", { description: file.name });
  }

  async function rodarInferencia() {
    if (!imagemArquivo || !spec) return;
    if (!sessao) {
      setErroInferencia(
        erroSessao ?? "O motor de inferência ainda não está pronto para este modelo.",
      );
      setEstadoInferencia("erro");
      return;
    }
    setEstadoInferencia("analisando");
    setErroInferencia(null);
    const inicio = performance.now();
    try {
      const ort = await import("onnxruntime-web");
      const { tensorData, letterbox } = await preprocessarImagem(imagemArquivo, spec.entrada);
      const tensor = new ort.Tensor("float32", tensorData, shapeDoTensorEntrada(spec.entrada));
      const saida = await sessao.session.run({ [spec.entrada.tensorName]: tensor });

      const outputsFormatado: Record<string, { data: ArrayLike<number>; dims: readonly number[] }> =
        {};
      for (const [nome, valor] of Object.entries(saida)) {
        outputsFormatado[nome] = {
          data: valor.data as unknown as ArrayLike<number>,
          dims: valor.dims,
        };
      }

      const decodificado = decodificarSaida(outputsFormatado, {
        classes: spec.classes,
        confThreshold: confiancaMinima,
        letterbox,
      });
      setResultado(decodificado);
      setTempoMs(performance.now() - inicio);
      setEstadoInferencia("completo");
      toast.success("Inspeção concluída");
    } catch (e) {
      setErroInferencia(
        e instanceof Error
          ? `Falha ao rodar a inferência: ${e.message}`
          : "Falha desconhecida ao rodar a inferência.",
      );
      setEstadoInferencia("erro");
      toast.error("Falha na inferência");
    }
  }

  function receberArquivoModelo(file?: File) {
    if (!file) return;
    const nome = file.name.toLowerCase();
    if (nome.endsWith(".onnx")) void handleOnnxSelecionado(file);
    else if (nome.endsWith(".zip")) void handleZipSelecionado(file);
    else if (nome.endsWith(".json") && estadoModelo === "pronto") void handleConfigSelecionado(file);
    else {
      const mensagem = nome.endsWith(".json")
        ? "Carregue primeiro um modelo para aplicar o config.json."
        : "Use um arquivo .onnx, .zip ou config.json.";
      toast.error("Arquivo não reconhecido", { description: mensagem });
    }
  }

  const avisosCarregamento = [...configErros, ...(erroSessao ? [erroSessao] : [])];

  return (
    <TooltipProvider delayDuration={250}>
    <div className="flex min-h-screen flex-col bg-background text-foreground antialiased transition-colors duration-300">
      <header className="sticky top-0 z-40 border-b border-border bg-background/90 px-4 py-3 shadow-sm backdrop-blur-xl sm:px-6">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="grid size-9 place-items-center rounded-md border border-primary/30 bg-primary/10 text-primary shadow-sm">
              <ScanLine className="size-5" aria-hidden="true" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className={`size-1.5 rounded-full ${estadoModelo === "pronto" ? "bg-success" : "bg-muted-foreground"}`} />
                <p className="font-mono text-[9px] font-bold uppercase tracking-[0.2em] text-primary">
                  {estadoModelo === "pronto" ? "sistema pronto" : "estação de inspeção"}
                </p>
              </div>
              <h1 className="font-display text-sm font-bold uppercase sm:text-base">Inspetor Universal ONNX</h1>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => onnxInputRef.current?.click()}>
              <Upload className="size-3.5" /> .onnx
            </Button>
            <Button variant="outline" size="sm" onClick={() => zipInputRef.current?.click()}>
              <FileArchive className="size-3.5" /> .zip
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => configInputRef.current?.click()}
              disabled={estadoModelo !== "pronto"}
            >
              <FileJson className="size-3.5" /> config.json
            </Button>
            {estadoModelo === "pronto" && (
              <Button variant="ghost" size="sm" onClick={resetarModelo}>
                <RotateCcw className="size-3.5" /> trocar modelo
              </Button>
            )}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={alternarTema}
                  aria-label={temaPronto && tema === "dark" ? "Ativar modo claro" : "Ativar modo escuro"}
                >
                  {temaPronto && tema === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent>{tema === "dark" ? "Modo claro" : "Modo escuro"}</TooltipContent>
            </Tooltip>
            <input
              ref={onnxInputRef}
              type="file"
              accept=".onnx"
              className="sr-only"
              onChange={(e) => handleOnnxSelecionado(e.target.files?.[0])}
            />
            <input
              ref={zipInputRef}
              type="file"
              accept=".zip"
              className="sr-only"
              onChange={(e) => handleZipSelecionado(e.target.files?.[0])}
            />
            <input
              ref={configInputRef}
              type="file"
              accept=".json"
              className="sr-only"
              onChange={(e) => handleConfigSelecionado(e.target.files?.[0])}
            />
          </div>
        </div>
      </header>

      <main className="mx-auto grid w-full max-w-[1600px] flex-1 gap-6 p-4 sm:p-7 lg:grid-cols-[25rem_minmax(0,1fr)] lg:p-8">
        {/* Coluna do modelo */}
        <section
          className={`flex flex-col gap-4 rounded-lg transition-colors ${arrastandoModelo ? "ring-2 ring-primary/25" : ""}`}
          onDragEnter={(e) => { e.preventDefault(); setArrastandoModelo(true); }}
          onDragOver={(e) => e.preventDefault()}
          onDragLeave={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setArrastandoModelo(false); }}
          onDrop={(e) => { e.preventDefault(); setArrastandoModelo(false); receberArquivoModelo(e.dataTransfer.files[0]); }}
        >
          {estadoModelo === "vazio" && (
            <div
              className={`animate-card-in min-h-80 rounded-lg border border-dashed p-6 transition-all duration-200 ${arrastandoModelo ? "border-primary bg-primary/10 shadow-lg" : "border-border bg-card hover:-translate-y-0.5 hover:border-primary/50 hover:shadow-md"}`}
            >
              <div className="flex h-full flex-col justify-center text-center">
                <div className="mx-auto grid size-14 place-items-center rounded-lg border border-primary/25 bg-primary/10 text-primary">
                  <Boxes className="size-7" />
                </div>
                <h2 className="mt-4 font-display text-base font-bold">Inicie uma inspeção</h2>
                <p className="mt-1 text-xs text-muted-foreground">Solte aqui um .onnx ou pacote .zip</p>
                <div className="my-5 grid gap-2 text-left text-xs">
                  {[["01", "Carregue um modelo"], ["02", "Envie uma imagem"], ["03", "Veja o resultado"]].map(([n, texto]) => (
                    <div key={n} className="flex items-center gap-3 border-t border-border pt-2 first:border-0 first:pt-0">
                      <span className="font-mono text-[10px] font-bold text-primary">{n}</span>
                      <span>{texto}</span>
                    </div>
                  ))}
                </div>
                <Button onClick={() => onnxInputRef.current?.click()}>
                  <Upload className="size-4" /> selecionar modelo
                </Button>
              </div>
            </div>
          )}

          {estadoModelo === "carregando" && (
            <div className="min-h-80 space-y-4 rounded-lg border border-border bg-card p-5" aria-label="Lendo metadados do modelo">
              <div className="flex items-center gap-3"><div className="size-9 animate-pulse rounded bg-muted" /><div className="flex-1 space-y-2"><div className="h-3 w-2/3 animate-pulse rounded bg-muted"/><div className="h-2 w-1/2 animate-pulse rounded bg-muted"/></div></div>
              <div className="grid grid-cols-3 gap-2">{[0,1,2].map((i) => <div key={i} className="h-16 animate-pulse rounded bg-muted" />)}</div>
              {[0,1,2,3].map((i) => <div key={i} className="h-10 animate-pulse rounded bg-muted" />)}
              <p className="flex items-center gap-2 text-xs text-muted-foreground"><LoaderCircle className="size-3.5 animate-spin text-primary" /> Lendo metadados…</p>
            </div>
          )}

          {estadoModelo === "erro" && (
            <div className="grid min-h-64 place-items-center rounded-lg border border-destructive/40 bg-destructive/5 p-6 text-center">
              <AlertOctagon className="mx-auto mb-3 size-7 text-destructive" />
              <p className="font-display text-sm font-bold">Não foi possível carregar o modelo</p>
              <p className="mt-1 text-xs text-muted-foreground">{erroModelo}</p>
              <Button
                variant="outline"
                size="sm"
                className="mt-4"
                onClick={() => onnxInputRef.current?.click()}
              >
                Tentar outro arquivo
              </Button>
            </div>
          )}

          {estadoModelo === "pronto" && spec && (
            <>
              <ModelSpecCard
                spec={spec}
                confiancaMinima={confiancaMinima}
                onConfiancaMinimaChange={setConfiancaMinima}
                regrasTexto={regrasTexto}
                onRegrasTextoChange={setRegrasTexto}
                regrasErros={regrasParsed.erros}
                decisaoAtual={decisao}
                editandoRegras={editandoRegras}
                onToggleEditarRegras={() => setEditandoRegras((v) => !v)}
              />
              {avisosCarregamento.length > 0 && (
                <div className="space-y-1 rounded-lg border border-amber-500/30 bg-amber-500/5 p-3">
                  {avisosCarregamento.map((a, i) => (
                    <p
                      key={i}
                      className="flex items-start gap-1.5 text-[11px] leading-relaxed text-amber-600"
                    >
                      <TriangleAlert className="mt-0.5 size-3 shrink-0" /> {a}
                    </p>
                  ))}
                </div>
              )}
            </>
          )}
        </section>

        {/* Coluna de operação (imagem + resultado) */}
        <section className="flex min-w-0 flex-col gap-5">
          <div className="animate-card-in grid grid-cols-[minmax(0,1fr)_auto] items-end gap-3 [animation-delay:80ms]">
            <div className="min-w-0">
              <p className="mb-1 font-mono text-[10px] uppercase tracking-[0.18em] text-primary">
                Estação de inspeção
              </p>
              <h2 className="truncate font-display text-xl font-bold sm:text-2xl">
                Aquisição de imagem
              </h2>
            </div>
          </div>

          {spec && (
            <div className="animate-card-in grid gap-3 sm:grid-cols-2 [animation-delay:140ms]">
              <InfoBlock
                icon={<FileImage className="size-4" />}
                label={<Termo termo="Entrada · NCHW" explicacao="NCHW organiza o tensor em lote, canais, altura e largura." />}
                value={`[1 × ${spec.entrada.canais} × ${spec.entrada.altura} × ${spec.entrada.largura}]`}
                detail={spec.entrada.tensorName}
              />
              <InfoBlock
                icon={<Cpu className="size-4" />}
                label="Saída"
                value={spec.saida.nomes.join(", ")}
                detail={resultado ? resultado.tipo : "aguardando"}
              />
            </div>
          )}

          <div
            onDragEnter={(e) => { e.preventDefault(); setArrastandoImagem(true); }}
            onDragOver={(e) => e.preventDefault()}
            onDragLeave={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setArrastandoImagem(false); }}
            onDrop={(e) => { e.preventDefault(); setArrastandoImagem(false); escolherImagem(e.dataTransfer.files[0]); }}
            className={`group relative min-h-[390px] flex-1 overflow-hidden rounded-lg border bg-card shadow-sm transition-all duration-200 sm:min-h-[420px] ${arrastandoImagem ? "border-primary bg-primary/5 ring-2 ring-primary/20" : "border-border hover:shadow-md"}`}
          >
            {imagemUrl ? (
              <img
                src={imagemUrl}
                alt="Imagem enviada para inspeção"
                className="absolute inset-0 size-full object-contain"
              />
            ) : (
              <div className="absolute inset-0 grid place-items-center text-center text-muted-foreground">
                <div>
                  <ImagePlus className="mx-auto mb-2 size-7" />
                  <p className="text-xs">Envie uma imagem para inspecionar</p>
                </div>
              </div>
            )}
            {visualizacao === "deteccoes" && resultado?.tipo === "deteccao" && imagemDims && (
              <DetectionOverlay
                deteccoes={resultado.deteccoes}
                larguraOriginal={imagemDims.w}
                alturaOriginal={imagemDims.h}
              />
            )}
            {estadoInferencia === "analisando" && (
              <span className="animate-scan pointer-events-none absolute inset-x-0 top-0 z-10 h-0.5 bg-primary shadow-[0_0_18px_var(--primary)]" />
            )}

            {arrastandoImagem && (
              <div className="pointer-events-none absolute inset-3 z-20 grid place-items-center rounded-md border border-dashed border-primary bg-background/90 backdrop-blur-sm">
                <div className="text-center"><ImagePlus className="mx-auto mb-2 size-8 text-primary"/><p className="font-display text-sm font-bold">Solte para carregar a imagem</p></div>
              </div>
            )}

            <div className="absolute inset-x-0 bottom-0 flex flex-col gap-3 border-t border-border bg-background/88 p-4 backdrop-blur-sm sm:flex-row sm:items-center sm:justify-between">
              <p className="truncate text-sm font-medium text-foreground">
                {imagemArquivo?.name ?? "nenhuma imagem selecionada"}
              </p>
              <div className="flex shrink-0 gap-2">
                <Button variant="ghost" onClick={() => imgInputRef.current?.click()}>
                  <ImagePlus className="size-4" /> escolher
                </Button>
                <Button
                  onClick={rodarInferencia}
                  disabled={!spec || !imagemArquivo || estadoInferencia === "analisando"}
                >
                  <ScanLine className="size-4" />
                  {estadoInferencia === "analisando" ? "analisando" : "inspecionar"}
                </Button>
              </div>
            </div>
            <input
              ref={imgInputRef}
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={(e) => escolherImagem(e.target.files?.[0])}
            />
          </div>

          <div
            onClick={() => imgInputRef.current?.click()}
            className="flex min-h-16 flex-wrap items-center justify-center gap-3 rounded-lg border border-dashed border-border bg-card px-4 text-left transition-all hover:-translate-y-0.5 hover:border-primary/60 hover:shadow-md"
          >
            <Upload className="size-5 shrink-0 text-primary" />
            <span className="text-xs text-muted-foreground">
              Arraste a imagem ou clique para selecionar
            </span>
            <Button variant="outline" size="sm" onClick={() => imgInputRef.current?.click()}>selecionar</Button>
          </div>

          {resultado?.tipo === "deteccao" && imagemUrl && (
            <div className="flex items-center justify-between gap-3">
              <span className="text-xs text-muted-foreground">Visualização</span>
              <div className="flex rounded-md border border-border bg-muted p-0.5" aria-label="Comparar imagem original e detecções">
                <Button size="sm" variant={visualizacao === "original" ? "secondary" : "ghost"} onClick={() => setVisualizacao("original")}><ImageIcon className="size-3.5"/> original</Button>
                <Button size="sm" variant={visualizacao === "deteccoes" ? "secondary" : "ghost"} onClick={() => setVisualizacao("deteccoes")}><Layers3 className="size-3.5"/> detecções</Button>
              </div>
            </div>
          )}

          <ResultadoPainel
            estado={estadoInferencia}
            resultado={resultado}
            erro={erroInferencia}
            decisao={decisao}
            tempoMs={tempoMs}
            classes={spec?.classes ?? []}
          />
        </section>
      </main>
    </div>
    </TooltipProvider>
  );
}

function InfoBlock({
  label,
  icon,
  value,
  detail,
}: {
  label: React.ReactNode;
  icon: React.ReactNode;
  value: string;
  detail: string;
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-3 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
      <div className="mb-2 flex items-center gap-2 text-primary">
        {icon}
        <span className="font-mono text-[10px] uppercase tracking-widest">{label}</span>
      </div>
      <p className="truncate font-mono text-xs">{value}</p>
      <p className="truncate font-mono text-[10px] text-muted-foreground">{detail}</p>
    </div>
  );
}

function ResultadoPainel({
  estado,
  resultado,
  erro,
  decisao,
  tempoMs,
  classes,
}: {
  estado: EstadoInferencia;
  resultado: ResultadoInferencia | null;
  erro: string | null;
  decisao: DecisionResult | null;
  tempoMs: number | null;
  classes: string[];
}) {
  if (estado === "analisando") {
    return (
      <div className="grid min-h-32 place-items-center rounded-lg border-l-4 border-primary bg-card p-6 text-center shadow-sm">
        <ScanLine className="mx-auto mb-2 size-6 text-primary" />
        <p className="font-display text-sm font-bold">Processando inferência</p>
      </div>
    );
  }
  if (estado === "erro") {
    return (
      <div className="grid min-h-32 place-items-center rounded-lg border-l-4 border-destructive bg-card p-6 text-center">
        <AlertOctagon className="mx-auto mb-2 size-6 text-destructive" />
        <p className="font-display text-sm font-bold">Falha na inferência</p>
        <p className="mt-1 text-xs text-muted-foreground">{erro}</p>
      </div>
    );
  }
  if (estado !== "completo" || !resultado) {
    return (
      <div className="grid min-h-32 place-items-center rounded-lg border-l-4 border-border bg-card p-6 text-center">
        <Settings2 className="mx-auto mb-2 size-6 text-muted-foreground" />
        <p className="text-xs text-muted-foreground">
          O resultado aparece aqui depois de rodar a inspeção.
        </p>
      </div>
    );
  }

  return (
    <div className={`animate-result rounded-lg border-l-4 bg-card p-5 shadow-sm ${decisao?.tom === "ok" ? "border-success" : decisao?.tom === "atencao" ? "border-warning" : decisao?.tom === "alerta" ? "border-destructive" : "border-primary"}`}>
      <div className="mb-4 flex items-center justify-between gap-3">
        {decisao ? (
          <span className={`font-display text-lg font-bold ${decisao.tom === "ok" ? "text-success" : decisao.tom === "atencao" ? "text-warning" : decisao.tom === "alerta" ? "text-destructive" : "text-foreground"}`}>{decisao.rotulo}</span>
        ) : (
          <span className="font-display text-sm text-muted-foreground">
            Nenhuma regra de decisão correspondeu
          </span>
        )}
        {tempoMs !== null && (
          <span className="rounded-md border border-primary/25 bg-primary/10 px-3 py-1.5 font-mono text-sm font-bold text-primary">
            {tempoMs.toFixed(0)} ms
          </span>
        )}
      </div>

      {resultado.tipo === "classificacao" && (
        <div className="space-y-2">
          {classes.map((c) => (
            <ScoreBar
              key={c}
              nome={c}
              score={resultado.scores[c] ?? 0}
              destaque={c === resultado.classePrevista}
            />
          ))}
        </div>
      )}

      {resultado.tipo === "deteccao" && (
        <div className="space-y-2">
          <p className="mb-2 font-mono text-[10px] uppercase text-muted-foreground">
            {resultado.deteccoes.length} detecção(ões) acima do limiar
          </p>
          {resultado.deteccoes.length === 0 ? (
            <p className="text-xs text-muted-foreground">
              Nenhum objeto detectado com a confiança mínima atual.
            </p>
          ) : (
            resultado.deteccoes
              .slice()
              .sort((a, b) => b.score - a.score)
              .map((d, i) => <ScoreBar key={i} nome={d.className} score={d.score} destaque />)
          )}
        </div>
      )}

      {resultado.tipo === "bruto" && (
        <div className="space-y-2">
          {resultado.avisos.map((a, i) => (
            <p key={i} className="flex items-start gap-1.5 text-xs text-amber-600">
              <TriangleAlert className="mt-0.5 size-3 shrink-0" /> {a}
            </p>
          ))}
          <table className="mt-2 w-full font-mono text-[11px]">
            <thead className="text-muted-foreground">
              <tr>
                <th className="text-left">saída</th>
                <th className="text-left">shape</th>
                <th className="text-right">min</th>
                <th className="text-right">max</th>
                <th className="text-right">média</th>
              </tr>
            </thead>
            <tbody>
              {resultado.resumo.map((r) => (
                <tr key={r.nome} className="border-t border-border">
                  <td>{r.nome}</td>
                  <td>{r.shape.join("×")}</td>
                  <td className="text-right">{r.min.toFixed(3)}</td>
                  <td className="text-right">{r.max.toFixed(3)}</td>
                  <td className="text-right">{r.media.toFixed(3)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function ScoreBar({ nome, score, destaque }: { nome: string; score: number; destaque: boolean }) {
  return (
    <div
      className={`grid grid-cols-[minmax(0,1fr)_3.5rem] items-center gap-3 border p-2.5 transition-colors ${destaque ? "border-primary/50 bg-primary/5" : "border-border bg-background/35"}`}
    >
      <div className="min-w-0">
        <div className="mb-1 flex items-center justify-between gap-2">
          <span className="truncate text-xs font-bold uppercase">{nome}</span>
        </div>
        <div className="h-1 overflow-hidden rounded-full bg-border">
          <div
            className={`h-full origin-left animate-[score-fill_600ms_cubic-bezier(0.2,1,0.3,1)_both] ${destaque ? "bg-primary" : "bg-muted-foreground"}`}
            style={{ width: `${Math.min(100, score * 100)}%` }}
          />
        </div>
      </div>
      <span
        className={`text-right font-mono text-xs ${destaque ? "text-primary" : "text-muted-foreground"}`}
      >
        {(score * 100).toFixed(1)}%
      </span>
    </div>
  );
}

function Termo({ termo, explicacao }: { termo: string; explicacao: string }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button type="button" className="inline-flex items-center gap-1 border-b border-dotted border-current focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          {termo}<CircleHelp className="size-3" aria-hidden="true" />
        </button>
      </TooltipTrigger>
      <TooltipContent className="max-w-60 bg-popover text-popover-foreground shadow-lg">{explicacao}</TooltipContent>
    </Tooltip>
  );
}
