# Plano — refinamento do Inspetor Universal ONNX

## Objetivo
Melhorar aparência, acessibilidade e feedback visual sem alterar a leitura de modelos, inferência, regras ou persistência existentes.

## Implementação
- Criar tema claro/escuro com preferência inicial do sistema, alternância no cabeçalho e escolha persistida com segurança.
- Refinar a bancada em duas colunas no computador e uma no celular, com hierarquia industrial, contraste e estados semânticos.
- Tornar as áreas de modelo e imagem receptivas a arrastar e soltar, mantendo os seletores atuais.
- Adicionar estado inicial em três passos, carregamento em skeleton e notificações de sucesso/erro.
- Aplicar animações rápidas: entrada escalonada, escaneamento, veredito, barras e caixas de detecção; desativá-las com preferência de movimento reduzido.
- Adicionar comparação original/detecções, tempo de inferência em destaque e explicações curtas para termos técnicos.
- Garantir foco visível, rótulos acessíveis e textos alternativos.

## Limites
- Nenhum arquivo em src/lib será modificado.
- A lógica de parsing, sessão, inferência, decisão e armazenamento continuará intacta.

## Verificação
- Conferir desktop e celular.
- Exercitar upload de modelo, metadados, ajuste de confiança, upload de imagem e resultado quando houver um modelo ONNX disponível para teste.
- Confirmar ausência de erros no navegador e preservação dos metadados da página.
