# Integração do modelo ONNX no protótipo Lovable — o que foi feito

Este projeto é o export do Lovable (`foundry-sight-pro`) com o modelo real
`inspetor_fundidos.onnx` já integrado, rodando 100% no navegador via
`onnxruntime-web` (WebAssembly). Não é mais uma tela mockada.

## O que mudou em relação ao export original

1. **`package.json`** — adicionada a dependência `onnxruntime-web`.
2. **`public/model/`** — contém `inspetor_fundidos.onnx` e
   `inspetor_fundidos_config.json` (copiados dos arquivos que você enviou).
   São servidos como arquivos estáticos e carregados pelo navegador em tempo
   de execução.
3. **~~`public/ort/`~~ (removido)** — a primeira versão copiava os binários
   `.wasm`/`.mjs` do runtime ONNX de `node_modules/onnxruntime-web/dist` para
   cá, para funcionar offline. **Isso foi revertido**: assim que a versão de
   `onnxruntime-web` instalada mudasse (por exemplo, `bun install` resolvendo
   uma versão diferente da que foi copiada com `npm install`), os arquivos
   locais ficavam fora de sincronia com o código JS que os carrega, e o
   runtime falhava com `no available backend found` ao tentar importar
   dinamicamente `ort-wasm-simd-threaded.jsep.mjs`. Agora `onnxruntime-web`
   busca esses arquivos no CDN oficial (jsDelivr), que é sempre gerado a
   partir da versão exata instalada — sem risco de descompasso. O custo é
   que a demonstração passa a exigir internet no navegador de quem testa
   (ver "Limitações" no final deste arquivo).
4. **`src/lib/onnx-inference.ts`** (novo arquivo) — reproduz exatamente o
   pré-processamento do notebook (seção 12, função `preprocessar`):
   escala de cinza → resize 128×128 → normalização com `media`/`desvio` do
   `inspetor_fundidos_config.json` → tensor `[1,1,128,128]` → `sigmoid(logit)`
   → compara com `limiar_decisao` (0.06) para decidir `ok` ou `defeito`.
5. **`src/routes/index.tsx`** — a tela de inspeção agora chama
   `inspecionarImagem()` de verdade ao clicar em "inspecionar", em vez de
   sortear um resultado fixo depois de um `setTimeout`. Os blocos de
   entrada/saída, mapeamento de classes (2 classes: `ok` e `defeito`) e o
   laudo técnico mostram os números reais devolvidos pelo modelo (P(defeito),
   logit, limiar, tempo de inferência).

`node_modules/` **não** está incluído neste ZIP (ficaria com centenas de MB).
Rode a instalação abaixo antes de usar o projeto.

## Como rodar localmente

Pré-requisito: Node.js 18+ instalado.

```bash
cd foundry-sight-pro-main
npm install
npm run dev
```

Abra o endereço que aparecer no terminal (normalmente `http://localhost:5173`).
Envie uma foto de uma peça fundida (ou use a imagem de exemplo já carregada) e
clique em **inspecionar**. A primeira inferência demora um pouco mais
(carregando o modelo, ~6 MB, e o runtime WASM, ~11 MB); as seguintes são
quase instantâneas.

## Validação já feita nesta entrega

- `npx tsc --noEmit`: sem erros de tipo.
- `npx vite build`: build de produção completo sem falhas.
- `npx vite dev` + requisições HTTP diretas: `/model/inspetor_fundidos.onnx`,
  `/model/inspetor_fundidos_config.json` e `/ort/ort-wasm-simd-threaded.wasm`
  respondem 200 com o tamanho esperado.
- O `.onnx` foi carregado com `onnxruntime` (Python) fora do navegador para
  confirmar nomes de entrada/saída (`entrada` → `logit`), forma dinâmica de
  lote e que a inferência roda sem erros.

O que **não** foi testado neste ambiente: a execução real dentro de um
navegador com Chromium (o sandbox aqui não tem acesso de rede para baixar o
Chromium do Playwright). Ou seja, a lógica está verificada ponta a ponta,
mas peço que você confirme visualmente ao rodar `npm run dev` na sua máquina.

## Observação sobre a conversão para tons de cinza

O `Canvas 2D` do navegador usa os mesmos coeficientes de luminância do Pillow
(`0.299·R + 0.587·G + 0.114·B`). Como as fotos do dataset já são
monocromáticas (R=G=B), isso não deve causar nenhuma diferença perceptível
para peças fotografadas do mesmo jeito que o dataset original. Para fotos
coloridas seria uma aproximação razoável, mas não bit-a-bit idêntica ao
Pillow — aceitável para uma demonstração local.

## Se o navegador reclamar de "SharedArrayBuffer" ou COOP/COEP

Não deve acontecer: o runtime roda com 1 thread (`ort.env.wasm.numThreads = 1`),
que não exige os cabeçalhos de isolamento de origem.

## Gerenciador de pacotes: use Bun, não npm

Este projeto tem `bun.lock` — ele é gerenciado pelo **Bun**, não pelo npm.
Rodar `npm install` aqui cria sua própria resolução de dependências, que pode
divergir da travada em `bun.lock` (foi exatamente essa mistura, em conjunto
com a cópia manual de binários descrita acima, que causou a falha real
relatada nesta integração). Use sempre:

```bash
bun install
bun run dev
```

## Bug real encontrado e corrigido nesta versão

Ao testar via túnel (Colab + Cloudflare), a inspeção falhava com:

```
Falha na inferência: no available backend found. ERR: [wasm] TypeError:
Failed to fetch dynamically imported module: .../ort/ort-wasm-simd-threaded.jsep.mjs?import
```

Causa: os binários do runtime ONNX estavam copiados manualmente para
`public/ort/`, e essa cópia ficou desalinhada com a versão de
`onnxruntime-web` de fato instalada (agravado por instalar com `npm` num
projeto travado com `bun.lock`). Correção aplicada em
`src/lib/onnx-inference.ts`: removida a linha `ort.env.wasm.wasmPaths = "/ort/"`,
deixando o próprio `onnxruntime-web` resolver os arquivos certos a partir do
CDN oficial, que corresponde sempre à versão exatamente instalada. A pasta
`public/ort/` foi removida por não ser mais usada.
