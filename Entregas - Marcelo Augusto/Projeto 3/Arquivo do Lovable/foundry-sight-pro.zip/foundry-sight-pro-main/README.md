# Casting Defect Insight

Você é um especialista em UI/UX design focado em interfaces de machine learning e inferência de modelos de IA. Sua tarefa é criar um protótipo MVP (produto viável mínimo) de uma interface moderna no Lovable que demonstre a inferência de um modelo de IA treinado pelo usuário para **identificação de defeitos em peças fundidas**.

**Objetivo:**

Desenvolver uma interface web funcional e visualmente impactante que exiba os resultados de inferência do modelo de detecção de defeitos de forma clara e intuitiva, com foco em prototipagem rápida e funcionalidade essencial. O design deve transmitir **confiabilidade e precisão técnica apropriados para uso industrial**, alinhando-se com padrões visuais e de usabilidade esperados em ambientes de manufatura e controle de qualidade.

**Referência de Design:**

Crie um design original e refinado, visualmente mais atrativo e polido do que a imagem anexada (`image.png`). Use-a como referência técnica para entender a estrutura de dados e fluxo de informações, mas não replique seu design. O design final deve:

- Usar uma paleta de cores sofisticada com fundo escuro (azul-marinho ou cinza escuro) e acentos em tons vibrantes (azul-teal, ciano ou similar), evocando **clareza técnica e profissionalismo industrial**

- Implementar containers com bordas arredondadas e espaçamento generoso para elegância visual

- Manter um layout limpo, moderno e bem hierarquizado

- Incorporar tipografia clara e hierarquia visual forte

- Ser polido, profissional e transmitir qualidade, confiabilidade e competência técnica apropriadas para ambientes industriais

- Ser responsivo em diferentes tamanhos de tela

- Usar ícones e elementos visuais para melhorar usabilidade

- Adicionar animações sutis e transições suaves onde apropriado

**Seções Obrigatórias:**

1. **Header:** Nome do modelo, tamanho do arquivo e framework (ex: PyTorch, ONNX)

2. **Informações de Entrada (ENTRADA):** Tipo de input (imagem), dimensões e tipo de dado

3. **Informações de Saída (SAÍDA):** Tipo de output, dimensões e tipo de dado

4. **Mapeamento de Classes:** Liste as classes de defeitos que o modelo detecta com identificadores

5. **Área de Teste:** Permita upload de imagem da peça fundida para testar o modelo em tempo real

6. **Resultados:** Exiba as predições com confiança/probabilidade de forma clara e destacada, indicando presença ou ausência de defeitos

**Requisitos Funcionais (MVP):**

Priorize funcionalidade essencial: renderização correta dos dados, upload de imagem funcional, exibição de resultados de detecção de defeitos. Mantenha o código limpo e bem estruturado, mas evite funcionalidades secundárias ou otimizações prematuras que não sirvam ao propósito do protótipo.

**Tecnologia:**

Implemente no Lovable usando as melhores práticas de design web moderno. Garanta que o código seja limpo, bem estruturado e fácil de manter.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://foundry-sight-pro.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/1771e11a-48ad-418d-9626-c44fddc61909).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
