import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  AlertOctagon,
  Box,
  CheckCircle2,
  Cpu,
  FileImage,
  ImagePlus,
  LoaderCircle,
  ScanLine,
  ShieldCheck,
  TriangleAlert,
  Upload,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import samplePart from "@/assets/cast-part-inspection.jpg";
import {
  carregarConfig,
  inspecionarImagem,
  preAquecerModelo,
  type ModeloConfig,
  type ResultadoInspecao,
} from "@/lib/onnx-inference";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ForgeVision — Inspeção de Fundidos" },
      { name: "description", content: "Teste um modelo de visão computacional para identificar defeitos em peças fundidas." },
      { property: "og:title", content: "ForgeVision — Inspeção de Fundidos" },
      { property: "og:description", content: "Bancada de inferência para controle de qualidade industrial." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: InspectionWorkbench,
});

type Stage = "ready" | "analyzing" | "complete" | "error";

function InspectionWorkbench() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [imageUrl, setImageUrl] = useState(samplePart);
  const [fileName, setFileName] = useState("amostra_referencia.jpg");
  const [file, setFile] = useState<File | null>(null);
  const [stage, setStage] = useState<Stage>("ready");
  const [resultado, setResultado] = useState<ResultadoInspecao | null>(null);
  const [config, setConfig] = useState<ModeloConfig | null>(null);
  const [erro, setErro] = useState<string | null>(null);

  // Pré-carrega a sessão ONNX e a configuração assim que a página monta, para que
  // o primeiro clique em "inspecionar" não pague o custo de carregar o modelo.
  useEffect(() => {
    preAquecerModelo();
    carregarConfig()
      .then(setConfig)
      .catch((e) => setErro(String(e?.message ?? e)));
  }, []);

  useEffect(() => {
    return () => {
      if (imageUrl.startsWith("blob:")) URL.revokeObjectURL(imageUrl);
    };
  }, [imageUrl]);

  function chooseImage(selecionado?: File) {
    if (!selecionado) return;
    setImageUrl(URL.createObjectURL(selecionado));
    setFileName(selecionado.name);
    setFile(selecionado);
    setResultado(null);
    setErro(null);
    setStage("ready");
  }

  async function inspect() {
    if (!file) {
      setErro("Selecione uma imagem antes de inspecionar.");
      return;
    }
    setStage("analyzing");
    setErro(null);
    try {
      const r = await inspecionarImagem(file);
      setResultado(r);
      setStage("complete");
    } catch (e) {
      console.error(e);
      setErro(e instanceof Error ? e.message : "Falha ao rodar a inferência ONNX.");
      setStage("error");
    }
  }

  const isComplete = stage === "complete" && resultado !== null;
  const isDefeito = resultado?.classe === "defeito";
  const tamanhoModeloMb = 6.01; // inspetor_fundidos.onnx ≈ 6.0 MB

  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground antialiased">
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 px-4 backdrop-blur-md sm:px-6">
        <div className="mx-auto grid min-h-16 max-w-[1600px] grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
          <div className="flex min-w-0 items-center gap-3">
            <div className="grid size-9 shrink-0 place-items-center rounded-sm border border-primary/40 bg-primary/10 text-primary">
              <Box className="size-4" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <h1 className="truncate font-display text-sm font-bold uppercase sm:text-base">ForgeVision <span className="text-muted-foreground">/ QA-04</span></h1>
              <p className="truncate font-mono text-[10px] uppercase text-muted-foreground sm:text-[11px]">inspetor_fundidos.onnx · {tamanhoModeloMb.toFixed(1)} MB · PyTorch / ONNX (rodando no navegador)</p>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2 font-mono text-[10px] uppercase">
            <span className="hidden text-muted-foreground sm:inline">Motor</span>
            <span className="inline-flex items-center gap-2 rounded-sm border border-primary/30 bg-primary/10 px-2.5 py-1.5 text-primary"><span className="size-1.5 rounded-full bg-primary" /> {config ? "pronto" : "carregando…"}</span>
          </div>
        </div>
      </header>

      <main className="mx-auto grid w-full max-w-[1600px] flex-1 gap-px bg-border lg:grid-cols-[minmax(0,1fr)_30rem]">
        <section className="flex min-w-0 flex-col gap-5 bg-background p-4 sm:p-7 lg:p-8">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-3">
            <div className="min-w-0">
              <p className="mb-1 font-mono text-[10px] uppercase tracking-[0.18em] text-primary">Estação de inspeção</p>
              <h2 className="truncate font-display text-xl font-bold sm:text-2xl">Aquisição de imagem</h2>
            </div>
            <span className="hidden font-mono text-[10px] uppercase text-muted-foreground sm:block">Demonstração local</span>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <InfoBlock label="Entrada" icon={<FileImage className="size-4" />} title="imagem" value={`[1 × 1 × ${config?.img_size ?? 128} × ${config?.img_size ?? 128}]`} detail="float32 · tons de cinza" />
            <InfoBlock label="Saída" icon={<Cpu className="size-4" />} title="logit" value="[1]" detail="float32 · sigmoid → P(defeito)" />
          </div>

          <div className="group relative min-h-[390px] flex-1 overflow-hidden rounded-lg border border-border bg-card sm:min-h-[470px]">
            <img src={imageUrl} alt="Peça fundida preparada para inspeção" width={1200} height={900} className="absolute inset-0 size-full object-cover opacity-75 grayscale transition duration-700 group-hover:grayscale-0" />
            <div className="pointer-events-none absolute inset-5 border border-primary/25">
              <span className="absolute left-3 top-3 bg-background/85 px-2 py-1 font-mono text-[9px] uppercase text-primary">IMG_01 · pré-processamento ativo</span>
              <span className="absolute bottom-3 right-3 bg-background/85 px-2 py-1 font-mono text-[9px] uppercase text-primary">{config?.img_size ?? 128} × {config?.img_size ?? 128} · cinza</span>
              {stage === "analyzing" && <span className="animate-scan absolute inset-x-0 top-0 h-px bg-primary shadow-[0_0_16px_var(--primary)]" />}
              {isComplete && (
                <div className="absolute left-4 top-4 max-w-[80%]">
                  <span className={`whitespace-nowrap px-1.5 py-1 font-mono text-[9px] font-bold ${isDefeito ? "bg-primary text-primary-foreground" : "bg-emerald-500 text-emerald-950"}`}>
                    {isDefeito ? "DEFEITO" : "OK"} · {(resultado!.confianca * 100).toFixed(1).replace(".", ",")}%
                  </span>
                </div>
              )}
            </div>
            <div className="absolute inset-x-0 bottom-0 flex flex-col gap-3 bg-background/88 p-4 backdrop-blur-sm sm:flex-row sm:items-center sm:justify-between">
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{fileName}</p>
                <p className="font-mono text-[10px] text-muted-foreground">JPG / PNG / WEBP</p>
              </div>
              <div className="flex shrink-0 gap-2">
                <Button variant="ghost" onClick={() => inputRef.current?.click()} aria-label="Escolher outra imagem"><ImagePlus className="size-4" /> substituir</Button>
                <Button onClick={inspect} disabled={stage === "analyzing" || !file}><ScanLine className="size-4" />{stage === "analyzing" ? "analisando" : "inspecionar"}</Button>
              </div>
            </div>
            <input ref={inputRef} type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" onChange={(event) => chooseImage(event.target.files?.[0])} />
          </div>

          <button type="button" onClick={() => inputRef.current?.click()} onDragOver={(event) => event.preventDefault()} onDrop={(event) => { event.preventDefault(); chooseImage(event.dataTransfer.files[0]); }} className="flex min-h-20 items-center justify-center gap-3 rounded-lg border border-dashed border-border bg-card/30 px-4 text-left transition-colors hover:border-primary/60 hover:bg-primary/5">
            <Upload className="size-5 shrink-0 text-primary" />
            <span><strong className="block font-display text-sm">Enviar imagem da peça</strong><span className="text-xs text-muted-foreground">Arraste o arquivo ou clique para selecionar</span></span>
          </button>
        </section>

        <aside className="flex flex-col gap-7 bg-card p-4 sm:p-7 lg:border-l lg:border-border lg:p-8">
          <div>
            <p className="mb-1 font-mono text-[10px] uppercase tracking-[0.18em] text-primary">Laudo técnico</p>
            <h2 className="font-display text-xl font-bold uppercase">Resultado da inspeção</h2>
          </div>

          {stage === "analyzing" ? (
            <div className="grid min-h-40 place-items-center border-l-4 border-primary bg-background p-6 text-center">
              <div><LoaderCircle className="mx-auto mb-3 size-7 animate-spin text-primary" /><p className="font-display font-bold">Processando inferência</p><p className="mt-1 text-xs text-muted-foreground">Normalizando imagem e avaliando classes</p></div>
            </div>
          ) : stage === "error" ? (
            <div className="grid min-h-40 place-items-center border-l-4 border-destructive bg-background p-6 text-center">
              <div><AlertOctagon className="mx-auto mb-3 size-7 text-destructive" /><p className="font-display font-bold">Falha na inferência</p><p className="mt-1 text-xs text-muted-foreground">{erro}</p></div>
            </div>
          ) : stage === "ready" && !isComplete ? (
            <div className="grid min-h-40 place-items-center border-l-4 border-border bg-background p-6 text-center">
              <div><ScanLine className="mx-auto mb-3 size-7 text-muted-foreground" /><p className="font-display font-bold">Imagem pronta para inspeção</p><p className="mt-1 text-xs text-muted-foreground">Inicie a análise para gerar um novo laudo</p></div>
            </div>
          ) : (
            <div className="animate-result border-l-4 border-primary bg-background p-6">
              <div className="mb-6 flex items-start justify-between gap-4">
                {isDefeito ? (
                  <span className="inline-flex items-center gap-1.5 border border-primary/30 bg-primary/10 px-2 py-1 font-mono text-[9px] font-bold text-primary"><TriangleAlert className="size-3" /> ANOMALIA</span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 border border-emerald-500/30 bg-emerald-500/10 px-2 py-1 font-mono text-[9px] font-bold text-emerald-500"><CheckCircle2 className="size-3" /> CONFORME</span>
                )}
                <div className="text-right">
                  <p className={`font-display text-3xl font-bold uppercase ${isDefeito ? "text-primary" : "text-emerald-500"}`}>{isDefeito ? "Defeito" : "OK"}</p>
                  <p className="font-mono text-[10px] text-muted-foreground">{isDefeito ? "REPROVADO" : "APROVADO"}</p>
                </div>
              </div>
              <div className="flex items-end justify-between"><span className="text-xs text-muted-foreground">Confiança</span><span className="font-mono text-2xl font-medium">{(resultado!.confianca * 100).toFixed(1).replace(".", ",")}%</span></div>
              <div className="mt-3 h-1 overflow-hidden bg-border"><div className={`h-full ${isDefeito ? "bg-primary" : "bg-emerald-500"}`} style={{ width: `${resultado!.confianca * 100}%` }} /></div>
              <div className="mt-4 grid grid-cols-2 gap-3 border-t border-border pt-4 font-mono text-[10px] text-muted-foreground">
                <span>P(defeito) = {(resultado!.probabilidadeDefeito * 100).toFixed(2).replace(".", ",")}%</span>
                <span className="text-right">limiar = {resultado!.limiarUsado.toFixed(2).replace(".", ",")}</span>
                <span>logit = {resultado!.logit.toFixed(4)}</span>
                <span className="text-right">{resultado!.tempoMs.toFixed(0)} ms</span>
              </div>
            </div>
          )}

          <div>
            <div className="mb-3 flex items-center justify-between border-b border-border pb-2"><h3 className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Mapeamento de classes</h3><span className="font-mono text-[10px] text-muted-foreground">2 classes</span></div>
            <div className="space-y-2">
              <ClassRow id="00" name="Peça conforme (ok)" score={isComplete ? (1 - resultado!.probabilidadeDefeito) * 100 : 0} active={isComplete && !isDefeito} />
              <ClassRow id="01" name="Defeito" score={isComplete ? resultado!.probabilidadeDefeito * 100 : 0} active={isComplete && isDefeito} />
            </div>
          </div>

          <div className="mt-auto space-y-3 border-t border-border pt-6">
            <div className="flex items-start gap-3 rounded-lg border border-border bg-background/40 p-4">
              {isComplete ? <ShieldCheck className="mt-0.5 size-5 shrink-0 text-primary" /> : <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-muted-foreground" />}
              <div>
                <p className="font-display text-sm font-bold">{isComplete ? "Revisão manual recomendada" : "Aguardando resultado"}</p>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  {isComplete
                    ? isDefeito
                      ? "O modelo classificou a peça como defeituosa. Encaminhe para reinspeção humana antes da expedição."
                      : "O modelo não encontrou indícios de defeito. O limiar de decisão prioriza recall alto (poucos defeitos passam despercebidos)."
                    : "Os dados do diagnóstico aparecerão após a inspeção."}
                </p>
              </div>
            </div>
            <p className="text-center font-mono text-[9px] uppercase text-muted-foreground">Inferência real via onnxruntime-web (WASM), 100% no navegador</p>
          </div>
        </aside>
      </main>

      <footer className="border-t border-border bg-background px-4 py-2 font-mono text-[9px] uppercase text-muted-foreground sm:px-6">
        <div className="mx-auto flex max-w-[1600px] items-center justify-between gap-4"><span>Demonstração local · inspetor_fundidos.onnx</span><span className="inline-flex items-center gap-2 text-foreground"><span className="size-1.5 rounded-full bg-primary" /> {config ? "engine ready" : "carregando modelo…"}</span></div>
      </footer>
    </div>
  );
}

function InfoBlock({ label, icon, title, value, detail }: { label: string; icon: React.ReactNode; title: string; value: string; detail: string }) {
  return <div className="rounded-lg border border-border bg-card/55 p-4"><div className="mb-3 flex items-center gap-2 text-primary">{icon}<span className="font-mono text-[10px] uppercase tracking-widest">{label}</span></div><div className="flex items-end justify-between gap-3"><div><p className="font-display text-sm font-bold">{title}</p><p className="mt-1 font-mono text-xs text-primary">{value}</p></div><span className="font-mono text-[9px] text-muted-foreground">{detail}</span></div></div>;
}

function ClassRow({ id, name, score, active }: { id: string; name: string; score: number; active: boolean }) {
  return <div className={`grid grid-cols-[2rem_minmax(0,1fr)_3.5rem] items-center gap-3 border p-3 transition-colors ${active ? "border-primary/50 bg-primary/5" : "border-border bg-background/35"}`}><span className="font-mono text-[10px] text-muted-foreground">{id}</span><div className="min-w-0"><div className="mb-1.5 flex items-center justify-between gap-2"><span className="truncate text-xs font-bold uppercase">{name}</span></div><div className="h-0.5 bg-border"><div className={`h-full transition-all duration-700 ${active ? "bg-primary" : "bg-muted-foreground"}`} style={{ width: `${score}%` }} /></div></div><span className={`text-right font-mono text-xs ${active ? "text-primary" : "text-muted-foreground"}`}>{score.toFixed(1).replace(".", ",")}%</span></div>;
}
