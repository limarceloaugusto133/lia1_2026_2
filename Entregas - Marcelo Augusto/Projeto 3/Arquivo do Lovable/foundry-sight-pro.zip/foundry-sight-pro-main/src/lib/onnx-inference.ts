// Inferência do modelo "Inspetor Visual de Defeitos em Peças Fundidas" no navegador.
//
// Reproduz EXATAMENTE o pré-processamento usado no treino/avaliação (ver notebook,
// seção 12 — funções `preprocessar` e `prever`):
//   1) converter para escala de cinza ("L")
//   2) redimensionar para IMG_SIZE x IMG_SIZE com interpolação bilinear
//   3) escalar de 0-255 para 0-1
//   4) normalizar com (x - media) / desvio, usando media/desvio calculados no treino
//   5) tensor de entrada [1, 1, IMG_SIZE, IMG_SIZE]
//   6) rede devolve 1 logit -> sigmoid(logit) = P(defeito)
//   7) decisão = P(defeito) >= limiar_decisao

export interface ModeloConfig {
  nome_projeto: string;
  classes: Record<string, string>;
  classe_positiva: string;
  img_size: number;
  canais: number;
  normalizacao: { media: number; desvio: number; origem: string };
  limiar_decisao: number;
  limiar_criterio: string;
  arquitetura: string;
  metricas_teste: {
    auc_roc: number;
    recall_defeito_limiar_padrao: number;
    recall_defeito_limiar_escolhido: number;
    precisao_defeito_limiar_escolhido: number;
  };
}

export interface ResultadoInspecao {
  classe: "ok" | "defeito";
  probabilidadeDefeito: number;
  confianca: number;
  logit: number;
  limiarUsado: number;
  tempoMs: number;
}

let ortModulePromise: Promise<typeof import("onnxruntime-web")> | null = null;
let sessionPromise: Promise<import("onnxruntime-web").InferenceSession> | null = null;
let configPromise: Promise<ModeloConfig> | null = null;

// Carrega o runtime ONNX só no navegador (evita quebrar o build/SSR do TanStack Start).
function carregarOrt() {
  if (!ortModulePromise) {
    ortModulePromise = import("onnxruntime-web").then((ort) => {
      // Os binarios .wasm/.mjs do runtime NAO sao mais copiados a mao para
      // /public/ort. Aquela copia manual ficava fora de sincronia toda vez que a
      // versao instalada de onnxruntime-web mudava (ex.: 'bun install' resolvendo
      // uma versao diferente da que foi copiada com 'npm install' em outra
      // maquina) — foi exatamente essa combinacao que produziu o erro observado
      // ("no available backend found... Failed to fetch dynamically imported
      // module .../ort-wasm-simd-threaded.jsep.mjs"). Deixando wasmPaths por
      // conta do padrao do onnxruntime-web, ele mesmo busca os arquivos certos
      // no CDN oficial (jsDelivr), sempre casados com a versao exata instalada.
      // 1 thread: evita exigir os cabecalhos COOP/COEP (isolamento de origem) que
      // o modo multi-thread do WASM precisa. Para uma imagem unica, e rapido o
      // suficiente.
      ort.env.wasm.numThreads = 1;
      ort.env.wasm.simd = true;
      return ort;
    });
  }
  return ortModulePromise;
}

export function carregarConfig(): Promise<ModeloConfig> {
  if (!configPromise) {
    configPromise = fetch("/model/inspetor_fundidos_config.json").then((resposta) => {
      if (!resposta.ok) throw new Error("Não foi possível carregar a configuração do modelo.");
      return resposta.json();
    });
  }
  return configPromise;
}

async function carregarSessao() {
  if (!sessionPromise) {
    sessionPromise = carregarOrt().then((ort) =>
      ort.InferenceSession.create("/model/inspetor_fundidos.onnx", {
        executionProviders: ["wasm"],
      })
    );
  }
  return sessionPromise;
}

// Pré-carrega sessão + config em paralelo (chamar cedo, ex.: ao montar a página).
export function preAquecerModelo() {
  void carregarSessao();
  void carregarConfig();
}

function sigmoid(x: number): number {
  return 1 / (1 + Math.exp(-x));
}

// Decodifica o arquivo de imagem, converte para cinza e redimensiona para
// imgSize x imgSize com interpolação bilinear via canvas 2D (equivalente ao
// Image.BILINEAR do Pillow usado no notebook).
async function preprocessarImagem(arquivo: File, imgSize: number): Promise<Float32Array> {
  const bitmap = await createImageBitmap(arquivo);

  const canvas = document.createElement("canvas");
  canvas.width = imgSize;
  canvas.height = imgSize;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas 2D indisponível neste navegador.");

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(bitmap, 0, 0, imgSize, imgSize);
  bitmap.close();

  const { data } = ctx.getImageData(0, 0, imgSize, imgSize);
  const cinza = new Float32Array(imgSize * imgSize);

  // Luminosidade ITU-R BT.601, igual à conversão "L" do Pillow (RGB -> escala de cinza).
  for (let i = 0, p = 0; i < data.length; i += 4, p++) {
    const r = data[i] ?? 0;
    const g = data[i + 1] ?? 0;
    const b = data[i + 2] ?? 0;
    cinza[p] = 0.299 * r + 0.587 * g + 0.114 * b;
  }

  return cinza;
}

export async function inspecionarImagem(arquivo: File): Promise<ResultadoInspecao> {
  const inicio = performance.now();

  const [sessao, config] = await Promise.all([carregarSessao(), carregarConfig()]);
  const ort = await carregarOrt();

  const { img_size: imgSize, normalizacao, limiar_decisao: limiar } = config;
  const cinza = await preprocessarImagem(arquivo, imgSize);

  const entrada = new Float32Array(imgSize * imgSize);
  for (let i = 0; i < cinza.length; i++) {
    const pixel01 = (cinza[i] ?? 0) / 255.0;
    entrada[i] = (pixel01 - normalizacao.media) / normalizacao.desvio;
  }

  const tensorEntrada = new ort.Tensor("float32", entrada, [1, 1, imgSize, imgSize]);
  const saida = await sessao.run({ entrada: tensorEntrada });
  const logitTensor = saida["logit"];
  if (!logitTensor) throw new Error("A saída 'logit' não veio na resposta do ONNX Runtime.");
  const logit = (logitTensor.data as Float32Array)[0];
  if (logit === undefined) throw new Error("Tensor de saída veio vazio.");

  const probabilidadeDefeito = sigmoid(logit);
  const classe: "ok" | "defeito" = probabilidadeDefeito >= limiar ? "defeito" : "ok";
  const confianca = classe === "defeito" ? probabilidadeDefeito : 1 - probabilidadeDefeito;

  return {
    classe,
    probabilidadeDefeito,
    confianca,
    logit,
    limiarUsado: limiar,
    tempoMs: performance.now() - inicio,
  };
}
